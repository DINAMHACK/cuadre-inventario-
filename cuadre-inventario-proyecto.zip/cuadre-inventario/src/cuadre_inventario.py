#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Cuadre de Inventario / Kardex  -  100 % local
Cruza el Excel del Sistema (teorico) contra el Excel del Conteo Fisico
y exporta un acta en Excel con colores semaforo y formulas vivas.
"""
import os
import re
import difflib
import shutil
import subprocess
import sys
import time
import unicodedata
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

PALABRAS_HEADER = ["COD", "ITEM", "DESC", "PROD", "CANT", "STOCK", "SALDO", "BIEN", "PRECIO", "UNID"]
UMBRAL_SIMILITUD = 0.86


# ----------------------------------------------------------------- utilidades
def sin_tildes(texto):
    """'CÓDIGO' -> 'CODIGO' (para comparar encabezados sin importar las tildes)."""
    return "".join(c for c in unicodedata.normalize("NFD", str(texto)) if unicodedata.category(c) != "Mn")


def limpiar_texto(val):
    if pd.isna(val):
        return ""
    s = str(val).strip().upper()
    s = re.sub(r"\s+", " ", s)
    if re.fullmatch(r"\d+\.0", s):          # 1234.0 -> 1234 (codigos leidos como numero)
        s = s[:-2]
    return s


def limpiar_numero(val):
    if pd.isna(val):
        return 0.0
    if isinstance(val, (int, float)):
        return float(val)
    s = str(val).strip().replace(",", "")
    s = re.sub(r"[^\d.\-]", "", s)
    try:
        return float(s)
    except ValueError:
        return 0.0


def leer_excel_inteligente(ruta):
    """Lee el Excel detectando solo la fila donde empiezan los encabezados reales."""
    df_raw = pd.read_excel(ruta, header=None)
    mejor_fila, mejor_puntaje = 0, -1
    for i in range(min(20, len(df_raw))):
        celdas = [sin_tildes(x).upper() for x in df_raw.iloc[i].tolist() if pd.notna(x)]
        puntaje = sum(1 for c in celdas if any(p in c for p in PALABRAS_HEADER))
        if puntaje > mejor_puntaje:
            mejor_fila, mejor_puntaje = i, puntaje
    df = pd.read_excel(ruta, header=mejor_fila)
    df.columns = [str(c).strip() for c in df.columns]
    df = df.loc[:, ~df.columns.str.startswith("Unnamed")]
    return df


def _preparar(df, c_cod, c_desc, c_cant, c_precio=None):
    out = pd.DataFrame()
    out["cod"] = df[c_cod].apply(limpiar_texto)
    out["desc"] = df[c_desc].apply(limpiar_texto)
    out["cant"] = df[c_cant].apply(limpiar_numero)
    out["precio"] = df[c_precio].apply(limpiar_numero) if c_precio else 0.0
    out = out[(out["cod"] != "") | (out["desc"] != "")].copy()
    out["clave"] = out.apply(lambda r: r["cod"] if r["cod"] else "SIN_COD_" + r["desc"], axis=1)
    return out


def calcular_cuadre(df_t, df_f, t_cols, f_cols, fuzzy=True):
    """t_cols = (cod, desc, cant, precio|None); f_cols = (cod, desc, cant)."""
    t = _preparar(df_t, *t_cols)
    f = _preparar(df_f, *f_cols)
    t_grp = t.groupby("clave", as_index=False).agg(
        {"cod": "first", "desc": "first", "cant": "sum", "precio": "max"})
    f_grp = f.groupby("clave", as_index=False).agg(
        {"cod": "first", "desc": "first", "cant": "sum"})

    registros = {}
    for r in t_grp.itertuples():
        registros[r.clave] = {"codigo": r.cod if r.cod else "SIN CÓDIGO", "descripcion": r.desc,
                              "teorico": r.cant, "fisico": 0.0, "precio": r.precio}

    for r in f_grp.itertuples():
        if r.clave in registros:
            registros[r.clave]["fisico"] += r.cant
            if not registros[r.clave]["descripcion"] and r.desc:
                registros[r.clave]["descripcion"] = r.desc
            continue
        emparejado = False
        # Rescate por nombre parecido: solo cuando al conteo fisico le falta el codigo
        if fuzzy and not r.cod and r.desc:
            mejor, mejor_score = None, 0.0
            for k, v in registros.items():
                if not v["descripcion"]:
                    continue
                sm = difflib.SequenceMatcher(None, r.desc, v["descripcion"])
                if sm.real_quick_ratio() <= UMBRAL_SIMILITUD or sm.quick_ratio() <= UMBRAL_SIMILITUD:
                    continue
                sc = sm.ratio()
                if sc > UMBRAL_SIMILITUD and sc > mejor_score:
                    mejor, mejor_score = k, sc
            if mejor:
                registros[mejor]["fisico"] += r.cant
                emparejado = True
        if not emparejado:
            registros[r.clave] = {"codigo": r.cod if r.cod else "SIN CÓDIGO",
                                  "descripcion": r.desc, "teorico": 0.0,
                                  "fisico": r.cant, "precio": 0.0}

    filas = []
    for d in registros.values():
        dif = round(d["fisico"] - d["teorico"], 4)
        if abs(dif) < 0.0001:
            estado, dif = "CONFORME", 0.0
        elif dif < 0:
            estado = "FALTANTE"
        else:
            estado = "SOBRANTE"
        filas.append({"codigo": d["codigo"], "descripcion": d["descripcion"],
                      "teorico": round(d["teorico"], 2), "fisico": round(d["fisico"], 2),
                      "diferencia": round(dif, 2), "estado": estado,
                      "precio": round(d["precio"], 2),
                      "valor_dif": round(dif * d["precio"], 2)})
    res = pd.DataFrame(filas)
    if res.empty:
        return res
    orden = {"FALTANTE": 0, "SOBRANTE": 1, "CONFORME": 2}
    res["orden"] = res["estado"].map(orden)
    return res.sort_values(by=["orden", "descripcion"]).drop(columns=["orden"]).reset_index(drop=True)


def exportar_resultado(df_resultado, ruta):
    wb = Workbook()
    ws = wb.active
    ws.title = "CUADRE DE INVENTARIO"

    font_titulo = Font(name="Calibri", size=13, bold=True, color="FFFFFF")
    fill_titulo = PatternFill("solid", fgColor="1F4E78")
    font_header = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
    fill_header = PatternFill("solid", fgColor="2F5597")
    fills = {"CONFORME": PatternFill("solid", fgColor="E6F4EA"),
             "FALTANTE": PatternFill("solid", fgColor="FCE8E6"),
             "SOBRANTE": PatternFill("solid", fgColor="FEF7E0")}
    fonts = {"CONFORME": Font(name="Calibri", size=10, bold=True, color="137333"),
             "FALTANTE": Font(name="Calibri", size=10, bold=True, color="C5221F"),
             "SOBRANTE": Font(name="Calibri", size=10, bold=True, color="B06000")}
    lado = Side(style="thin", color="BFBFBF")
    borde = Border(left=lado, right=lado, top=lado, bottom=lado)

    ws.merge_cells("A1:H1")
    ws["A1"] = "REPORTE DE CUADRE DE INVENTARIO FÍSICO VS. SISTEMA (KARDEX)"
    ws["A1"].font = font_titulo
    ws["A1"].fill = fill_titulo
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 26

    headers = ["CÓDIGO", "DESCRIPCIÓN DEL ÍTEM", "STOCK SISTEMA", "CONTEO FÍSICO",
               "DIFERENCIA", "ESTADO", "PRECIO UNIT. (S/)", "VALOR DIFERENCIA (S/)"]
    ws.append(headers)
    ws.row_dimensions[2].height = 30
    for c in range(1, 9):
        cell = ws.cell(row=2, column=c)
        cell.font, cell.fill, cell.border = font_header, fill_header, borde
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    fmt_signo = "+#,##0.00;-#,##0.00;0.00"
    for idx, r in enumerate(df_resultado.itertuples(), start=3):
        ws.cell(row=idx, column=1, value=r.codigo).alignment = Alignment(horizontal="center")
        ws.cell(row=idx, column=2, value=r.descripcion).alignment = Alignment(horizontal="left")
        ws.cell(row=idx, column=3, value=r.teorico).number_format = "#,##0.00"
        ws.cell(row=idx, column=4, value=r.fisico).number_format = "#,##0.00"
        ws.cell(row=idx, column=5, value=f"=D{idx}-C{idx}").number_format = fmt_signo
        ws.cell(row=idx, column=6, value=r.estado).alignment = Alignment(horizontal="center")
        ws.cell(row=idx, column=7, value=r.precio).number_format = "#,##0.00"
        ws.cell(row=idx, column=8, value=f"=E{idx}*G{idx}").number_format = fmt_signo
        for c in range(1, 9):
            celda = ws.cell(row=idx, column=c)
            celda.border = borde
            celda.fill = fills[r.estado]
            if c in (5, 6, 8):
                celda.font = fonts[r.estado]

    fin = len(df_resultado) + 2
    ft = fin + 1
    ws.cell(row=ft, column=2, value="TOTALES GENERALES")
    ws.cell(row=ft, column=3, value=f"=SUM(C3:C{fin})").number_format = "#,##0.00"
    ws.cell(row=ft, column=4, value=f"=SUM(D3:D{fin})").number_format = "#,##0.00"
    ws.cell(row=ft, column=5, value=f"=SUM(E3:E{fin})").number_format = fmt_signo
    ws.cell(row=ft, column=8, value=f"=SUM(H3:H{fin})").number_format = fmt_signo
    for c in range(1, 9):
        celda = ws.cell(row=ft, column=c)
        celda.font = Font(bold=True)
        celda.border = borde
        celda.fill = PatternFill("solid", fgColor="D9E1F2")

    for i, ancho in enumerate([16, 48, 16, 16, 16, 15, 18, 22], start=1):
        ws.column_dimensions[get_column_letter(i)].width = ancho
    ws.freeze_panes = "A3"
    # Listo para imprimir: horizontal y todas las columnas en una sola hoja de ancho
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    wb.save(ruta)


# ------------------------------------------------------------------- interfaz
class CuadreInventarioApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Cuadre de Inventario / Kardex — 100 % Local")
        self.root.geometry("1180x720")
        self.root.minsize(980, 600)

        self.df_teorico = None
        self.df_fisico = None
        self.df_resultado = None
        self._construir_ui()

    def _construir_ui(self):
        frame_top = ttk.LabelFrame(self.root, text="1. Cargar archivos Excel (Sistema vs. Conteo Físico)", padding=8)
        frame_top.pack(fill="x", padx=10, pady=(10, 5))

        ttk.Button(frame_top, text="Cargar Excel Sistema (Teórico)", width=30,
                   command=self.cargar_teorico).grid(row=0, column=0, padx=5, pady=3)
        self.lbl_teorico = ttk.Label(frame_top, text="Ningún archivo seleccionado", foreground="gray")
        self.lbl_teorico.grid(row=0, column=1, sticky="w", padx=5)

        ttk.Button(frame_top, text="Cargar Excel Conteo Físico", width=30,
                   command=self.cargar_fisico).grid(row=1, column=0, padx=5, pady=3)
        self.lbl_fisico = ttk.Label(frame_top, text="Ningún archivo seleccionado", foreground="gray")
        self.lbl_fisico.grid(row=1, column=1, sticky="w", padx=5)

        ttk.Button(frame_top, text="📄 Extraer tablas de PDF o foto → Excel…", command=self.abrir_extractor).grid(
            row=0, column=2, rowspan=2, padx=(40, 5), sticky="e")
        frame_top.columnconfigure(1, weight=1)

        frame_map = ttk.LabelFrame(self.root, text="2. Asignar columnas de cada Excel", padding=8)
        frame_map.pack(fill="x", padx=10, pady=5)

        def combo(fila, col, ancho, etiqueta, col_lbl):
            ttk.Label(frame_map, text=etiqueta).grid(row=fila, column=col_lbl, padx=3, pady=2, sticky="e")
            cb = ttk.Combobox(frame_map, width=ancho, state="readonly")
            cb.grid(row=fila, column=col, padx=3, pady=2)
            return cb

        ttk.Label(frame_map, text="SISTEMA (TEÓRICO):", font=("TkDefaultFont", 9, "bold")).grid(row=0, column=0, sticky="w", padx=5)
        self.cb_t_cod = combo(0, 2, 15, "Código:", 1)
        self.cb_t_desc = combo(0, 4, 20, "Descripción:", 3)
        self.cb_t_cant = combo(0, 6, 14, "Cantidad:", 5)
        self.cb_t_precio = combo(0, 8, 13, "Precio (opc.):", 7)

        ttk.Label(frame_map, text="CONTEO FÍSICO:", font=("TkDefaultFont", 9, "bold")).grid(row=1, column=0, sticky="w", padx=5)
        self.cb_f_cod = combo(1, 2, 15, "Código:", 1)
        self.cb_f_desc = combo(1, 4, 20, "Descripción:", 3)
        self.cb_f_cant = combo(1, 6, 14, "Cantidad:", 5)

        self.var_fuzzy = tk.BooleanVar(value=True)
        ttk.Checkbutton(frame_map, text="Cruzar por nombre similar si falta código en el conteo físico",
                        variable=self.var_fuzzy).grid(row=2, column=0, columnspan=8, sticky="w", padx=5, pady=(4, 0))

        frame_act = ttk.Frame(self.root, padding=(10, 4))
        frame_act.pack(fill="x")
        ttk.Button(frame_act, text="▶ Procesar y Cruzar Inventario", command=self.procesar_cuadre).pack(side="left", padx=(0, 8))
        ttk.Button(frame_act, text="💾 Exportar Excel con Colores", command=self.exportar_excel).pack(side="left", padx=(0, 8))
        ttk.Button(frame_act, text="Limpiar Todo", command=self.limpiar_todo).pack(side="left")

        ttk.Label(frame_act, text="Filtrar vista:").pack(side="left", padx=(25, 5))
        self.cb_filtro = ttk.Combobox(frame_act, values=["TODOS", "CONFORME", "FALTANTE", "SOBRANTE"],
                                      width=14, state="readonly")
        self.cb_filtro.current(0)
        self.cb_filtro.pack(side="left")
        self.cb_filtro.bind("<<ComboboxSelected>>", lambda e: self.actualizar_tabla())

        self.lbl_resumen = ttk.Label(frame_act, text="Sin procesar", font=("TkDefaultFont", 9, "bold"))
        self.lbl_resumen.pack(side="right", padx=5)

        frame_tabla = ttk.Frame(self.root, padding=(10, 4))
        frame_tabla.pack(fill="both", expand=True)
        columnas = ("codigo", "descripcion", "teorico", "fisico", "diferencia", "estado", "precio", "valor_dif")
        self.tree = ttk.Treeview(frame_tabla, columns=columnas, show="headings", selectmode="browse")
        encabezados = {
            "codigo": ("CÓDIGO", 120, "center"), "descripcion": ("DESCRIPCIÓN DEL ÍTEM", 340, "w"),
            "teorico": ("SISTEMA", 90, "e"), "fisico": ("FÍSICO", 90, "e"),
            "diferencia": ("DIFERENCIA", 95, "e"), "estado": ("ESTADO", 110, "center"),
            "precio": ("PRECIO UNIT.", 95, "e"), "valor_dif": ("VALOR DIF. (S/)", 115, "e"),
        }
        for col, (texto, ancho, alin) in encabezados.items():
            self.tree.heading(col, text=texto)
            self.tree.column(col, width=ancho, anchor=alin)
        self.tree.tag_configure("CONFORME", background="#E6F4EA", foreground="#137333")
        self.tree.tag_configure("FALTANTE", background="#FCE8E6", foreground="#C5221F")
        self.tree.tag_configure("SOBRANTE", background="#FEF7E0", foreground="#B06000")

        sy = ttk.Scrollbar(frame_tabla, orient="vertical", command=self.tree.yview)
        sx = ttk.Scrollbar(frame_tabla, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        sy.grid(row=0, column=1, sticky="ns")
        sx.grid(row=1, column=0, sticky="ew")
        frame_tabla.rowconfigure(0, weight=1)
        frame_tabla.columnconfigure(0, weight=1)

        self.lbl_status = ttk.Label(self.root, text="Listo. Carga los dos archivos Excel para iniciar el cuadre.",
                                    relief="sunken", anchor="w", padding=(8, 3))
        self.lbl_status.pack(fill="x", side="bottom")

    # -- carga de archivos
    @staticmethod
    def _coincide(columna, clave):
        """La clave debe ser el inicio de una palabra de la columna ('ID' solo si es la palabra exacta)."""
        clave = sin_tildes(clave).upper()
        palabras = [w for w in re.split(r"[^A-Z0-9]+", sin_tildes(columna).upper()) if w]
        if clave == "P.U":                         # precio unitario escrito 'P.U.', 'P.U', 'P U'
            return "P.U" in sin_tildes(columna).upper() or ("P" in palabras and "U" in palabras)
        if clave == "ID":
            return "ID" in palabras
        return any(w.startswith(clave) for w in palabras)

    def _autoseleccionar(self, combo, columnas, claves, opcional=False):
        opciones = (["(Ninguno)"] + columnas) if opcional else list(columnas)
        combo["values"] = opciones
        combo.current(0)
        for clave in claves:                      # primero la clave más específica
            for idx, col in enumerate(columnas):
                if self._coincide(col, clave):
                    combo.current(idx + (1 if opcional else 0))
                    return

    # -- diálogos de archivo: selector nativo de Linux Mint (zenity) con respaldo al de Tk
    def _zenity(self, args):
        """Devuelve (usado, ruta). usado=False si zenity no está disponible o falla."""
        if not shutil.which("zenity"):
            return False, None
        try:
            p = subprocess.Popen(["zenity"] + args, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
            while p.poll() is None:
                self.root.update()
                time.sleep(0.03)
            salida = p.stdout.read().strip()
        except Exception:
            return False, None
        if p.returncode == 0:
            return True, salida
        if p.returncode == 1 or p.returncode < 0:  # el usuario canceló / cerró la ventana
            return True, None
        return False, None                         # error de zenity -> usar respaldo

    @staticmethod
    def _carpeta_inicial():
        home = os.path.expanduser("~")
        for nombre in ("Documentos", "Documents"):
            ruta = os.path.join(home, nombre)
            if os.path.isdir(ruta):
                return ruta
        return home

    def _pedir_archivo(self, titulo, nombre_filtro, patrones):
        usado, ruta = self._zenity(["--file-selection", f"--title={titulo}",
                                    f"--filename={self._carpeta_inicial()}/.xlsx",   # nombre ficticio: hace que zenity abra DENTRO de la carpeta
                                    f"--file-filter={nombre_filtro} | {patrones}",
                                    "--file-filter=Todos los archivos | *"])
        if usado:
            return ruta
        return filedialog.askopenfilename(
            title=titulo, initialdir=self._carpeta_inicial(),
            filetypes=[(nombre_filtro, patrones), ("Todos los archivos", "*.*")])

    def _pedir_excel(self, titulo):
        return self._pedir_archivo(titulo, "Archivos Excel", "*.xlsx *.xlsm *.xls")

    def _pedir_guardado(self, titulo, nombre):
        usado, ruta = self._zenity(["--file-selection", "--save", "--confirm-overwrite",
                                    f"--title={titulo}", f"--filename={self._carpeta_inicial()}/{nombre}/",   # la barra final hace que zenity muestre el nombre sugerido
                                    
                                    "--file-filter=Archivo Excel | *.xlsx"])
        if usado:
            if ruta:
                ruta = ruta.rstrip("/")
                if not ruta.lower().endswith(".xlsx"):
                    ruta += ".xlsx"
            return ruta
        return filedialog.asksaveasfilename(
            title=titulo, defaultextension=".xlsx", initialfile=nombre, initialdir=self._carpeta_inicial(),
            filetypes=[("Archivo Excel", "*.xlsx")])

    def _aplicar_teorico(self, df, nombre):
        self.df_teorico = df
        cols = [str(c) for c in df.columns]
        self.lbl_teorico.config(text=f"{nombre} ({len(df)} filas)", foreground="black")
        self._autoseleccionar(self.cb_t_cod, cols, ["COD", "ITEM", "SKU", "ID", "PATRIMONIAL"])
        self._autoseleccionar(self.cb_t_desc, cols, ["DESC", "NOMBRE", "PROD", "ARTICULO", "ARTÍCULO", "BIEN", "DETALLE", "DENOMINACION"])
        self._autoseleccionar(self.cb_t_cant, cols, ["CANT", "STOCK", "SALDO", "TEORICO", "TEÓRICO", "SISTEMA", "EXIST"])
        self._autoseleccionar(self.cb_t_precio, cols, ["PRECIO", "COSTO", "P.U", "UNIT", "VALOR"], opcional=True)
        self.lbl_status.config(text="Datos del Sistema cargados. Verifica las columnas asignadas.")

    def _aplicar_fisico(self, df, nombre):
        self.df_fisico = df
        cols = [str(c) for c in df.columns]
        self.lbl_fisico.config(text=f"{nombre} ({len(df)} filas)", foreground="black")
        self._autoseleccionar(self.cb_f_cod, cols, ["COD", "ITEM", "SKU", "ID", "PATRIMONIAL"])
        self._autoseleccionar(self.cb_f_desc, cols, ["DESC", "NOMBRE", "PROD", "ARTICULO", "ARTÍCULO", "BIEN", "DETALLE", "DENOMINACION"])
        self._autoseleccionar(self.cb_f_cant, cols, ["CANT", "FISICO", "FÍSICO", "CONTEO", "STOCK", "TOTAL"])
        self.lbl_status.config(text="Datos del Conteo Físico cargados. Pulsa 'Procesar y Cruzar Inventario'.")

    def cargar_teorico(self):
        ruta = self._pedir_excel("Seleccionar Excel del Sistema (Teórico)")
        if not ruta:
            return
        try:
            df = leer_excel_inteligente(ruta)
        except Exception as e:
            messagebox.showerror("Error al leer Excel", f"No se pudo abrir el archivo:\n{e}")
            return
        self._aplicar_teorico(df, os.path.basename(ruta))

    def cargar_fisico(self):
        ruta = self._pedir_excel("Seleccionar Excel del Conteo Físico")
        if not ruta:
            return
        try:
            df = leer_excel_inteligente(ruta)
        except Exception as e:
            messagebox.showerror("Error al leer Excel", f"No se pudo abrir el archivo:\n{e}")
            return
        self._aplicar_fisico(df, os.path.basename(ruta))

    def abrir_extractor(self):
        try:
            import extractor_tablas
        except Exception as e:
            messagebox.showerror("Falta un componente", f"No se pudo cargar el extractor de tablas:\n{e}")
            return
        extractor_tablas.abrir(self)

    # -- proceso
    def procesar_cuadre(self):
        if self.df_teorico is None or self.df_fisico is None:
            messagebox.showwarning("Faltan archivos", "Debes cargar tanto el Excel del Sistema como el del Conteo Físico.")
            return
        precio = self.cb_t_precio.get()
        t_cols = (self.cb_t_cod.get(), self.cb_t_desc.get(), self.cb_t_cant.get(),
                  None if precio in ("", "(Ninguno)") else precio)
        f_cols = (self.cb_f_cod.get(), self.cb_f_desc.get(), self.cb_f_cant.get())
        if not all(t_cols[:3]) or not all(f_cols):
            messagebox.showwarning("Faltan columnas", "Asigna Código, Descripción y Cantidad en ambos archivos.")
            return
        try:
            self.root.config(cursor="watch")
            self.root.update_idletasks()
            self.df_resultado = calcular_cuadre(self.df_teorico, self.df_fisico, t_cols, f_cols, self.var_fuzzy.get())
        except Exception as e:
            messagebox.showerror("Error al procesar", f"Ocurrió un problema al cruzar los datos:\n{e}")
            return
        finally:
            self.root.config(cursor="")
        self.actualizar_tabla()
        self.lbl_status.config(text=f"Cruce finalizado: {len(self.df_resultado)} ítems únicos analizados.")

    def actualizar_tabla(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        if self.df_resultado is None or self.df_resultado.empty:
            return
        filtro = self.cb_filtro.get()
        df = self.df_resultado if filtro == "TODOS" else self.df_resultado[self.df_resultado["estado"] == filtro]
        for r in df.itertuples():
            self.tree.insert("", "end", tags=(r.estado,), values=(
                r.codigo, r.descripcion, f"{r.teorico:g}", f"{r.fisico:g}",
                f"{r.diferencia:+g}" if r.diferencia != 0 else "0", r.estado,
                f"{r.precio:.2f}", f"{r.valor_dif:+.2f}" if r.valor_dif != 0 else "0.00"))
        est = self.df_resultado["estado"]
        self.lbl_resumen.config(text=f"Total: {len(est)} | Conformes: {(est == 'CONFORME').sum()} | "
                                     f"Faltantes: {(est == 'FALTANTE').sum()} | Sobrantes: {(est == 'SOBRANTE').sum()}")

    def exportar_excel(self):
        if self.df_resultado is None or self.df_resultado.empty:
            messagebox.showwarning("Sin datos", "Primero debes procesar el cuadre de inventario.")
            return
        ruta = self._pedir_guardado("Guardar Acta de Cuadre de Inventario", "Cuadre_Inventario_Kardex.xlsx")
        if not ruta:
            return
        try:
            exportar_resultado(self.df_resultado, ruta)
        except Exception as e:
            messagebox.showerror("Error al guardar", f"No se pudo guardar el archivo:\n{e}")
            return
        messagebox.showinfo("Exportado", f"Reporte guardado correctamente en:\n{ruta}")

    def limpiar_todo(self):
        self.df_teorico = self.df_fisico = self.df_resultado = None
        self.lbl_teorico.config(text="Ningún archivo seleccionado", foreground="gray")
        self.lbl_fisico.config(text="Ningún archivo seleccionado", foreground="gray")
        self.lbl_resumen.config(text="Sin procesar")
        for cb in (self.cb_t_cod, self.cb_t_desc, self.cb_t_cant, self.cb_t_precio,
                   self.cb_f_cod, self.cb_f_desc, self.cb_f_cant):
            cb.set("")
            cb["values"] = []
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.lbl_status.config(text="Pantalla limpia. Lista para un nuevo cuadre.")


def _ruta_log():
    return os.path.join(os.path.expanduser("~"), "cuadre_inventario_errores.log")


def _reportar_error(exc, val, tb, root=None):
    """Guarda el detalle del error en un archivo y avisa con una ventana (sin terminal)."""
    import traceback
    import datetime
    try:
        with open(_ruta_log(), "a", encoding="utf-8") as f:
            f.write(f"\n=== {datetime.datetime.now():%Y-%m-%d %H:%M:%S} ===\n")
            f.write("".join(traceback.format_exception(exc, val, tb)))
    except Exception:
        pass
    try:
        messagebox.showerror("Error inesperado",
                             f"Ocurrió un problema:\n{val}\n\nEl detalle se guardó en:\n{_ruta_log()}\n"
                             "Envíe ese archivo para que se pueda corregir.", parent=root)
    except Exception:
        pass


def main():
    if sys.platform == "win32":                    # nitidez en pantallas con escala > 100 %
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    root = tk.Tk()
    root.report_callback_exception = lambda e, v, t: _reportar_error(e, v, t, root)
    try:
        style = ttk.Style()
        if "clam" in style.theme_names():
            style.theme_use("clam")
    except Exception:
        pass
    icono = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icono.png")
    if os.path.exists(icono):
        try:
            root.iconphoto(True, tk.PhotoImage(file=icono))
        except Exception:
            pass
    CuadreInventarioApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
