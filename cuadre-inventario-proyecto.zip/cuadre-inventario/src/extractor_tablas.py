#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Extractor de tablas: PDF digital, PDF escaneado o foto  ->  tabla (DataFrame) -> Excel.
Usa pdfplumber para PDF con texto y OCR (Tesseract) para escaneados y fotos.
"""
import os
import re
import sys
import shutil
import threading
import statistics

_AQUI = os.path.dirname(os.path.abspath(__file__))
_VENDOR = os.path.join(_AQUI, "vendor")
if os.path.isdir(_VENDOR) and _VENDOR not in sys.path:
    sys.path.insert(0, _VENDOR)          # librerías incluidas con el programa

import pandas as pd

EXT_IMAGEN = (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp")
PATRONES_ARCHIVO = "*.pdf *.PDF " + " ".join(f"*{e} *{e.upper()}" for e in EXT_IMAGEN)
MODOS = {"Automático (recomendado)": "auto",
         "Solo PDF digital (sin OCR)": "pdf",
         "Escaneado o foto (OCR)": "ocr"}


# ------------------------------------------------------------- limpieza
def limpiar_celda(x):
    if x is None:
        return ""
    s = str(x).replace("\r", " ").replace("\n", " ")
    return re.sub(r"\s+", " ", s).strip()


def _es_numerico(s):
    return bool(re.fullmatch(r"[\s()\-+/%$S.,\d]+", s)) and any(c.isdigit() for c in s)


def _filas_limpias(filas):
    filas = [[limpiar_celda(c) for c in (f or [])] for f in filas]
    filas = [f for f in filas if any(f)]
    if not filas:
        return []
    ancho = max(len(f) for f in filas)
    filas = [f + [""] * (ancho - len(f)) for f in filas]
    vacias = [j for j in range(ancho) if not any(f[j] for f in filas)]
    return [[c for j, c in enumerate(f) if j not in vacias] for f in filas]


def _unir_encabezado(filas):
    """Si el encabezado viene en dos filas (celdas combinadas), las junta en una."""
    if len(filas) < 3:
        return filas
    f0, f1 = filas[0], filas[1]
    if len(f0) >= 3 and sum(1 for c in f0 if c) == 1 and sum(1 for c in f1 if c) >= len(f1) - 1:
        filas = filas[1:]                      # fila de título de la tabla (una sola celda con texto)
        if len(filas) < 3:
            return filas
        f0, f1 = filas[0], filas[1]
    vac0 = sum(1 for c in f0 if not c) / len(f0)
    if 0.2 <= vac0 <= 0.8 and all(f1) and not any(_es_numerico(c) for c in f1):
        arriba, ult = [], ""
        for c in f0:
            ult = c or ult
            arriba.append(ult)
        nuevo = [(a + " " + b).strip() if a != b else b for a, b in zip(arriba, f1)]
        return [nuevo] + filas[2:]
    return filas


def _nombres_unicos(cols):
    out, vistos = [], {}
    for i, c in enumerate(cols):
        c = c or f"Col_{i + 1}"
        if c in vistos:
            vistos[c] += 1
            c = f"{c}_{vistos[c]}"
        else:
            vistos[c] = 1
        out.append(c)
    return out


def _norm(fila):
    return [c.strip().upper() for c in fila]


def combinar_tablas(lista):
    """lista = [(pagina, filas)]. Une tablas de varias páginas quitando encabezados repetidos."""
    encabezado, filas_ok, paginas = None, [], []
    for pagina, filas in lista:
        filas = _filas_limpias(filas)
        if not filas:
            continue
        if encabezado is None:
            filas = _unir_encabezado(filas)
            encabezado, cuerpo = filas[0], filas[1:]
        else:
            cuerpo = filas
            if _norm(cuerpo[0][:len(encabezado)]) == _norm(encabezado[:len(cuerpo[0])]):
                cuerpo = cuerpo[1:]
        for f in cuerpo:
            if _norm(f[:len(encabezado)]) == _norm(encabezado[:len(f)]):
                continue
            filas_ok.append(f)
            paginas.append(pagina)
    if encabezado is None:
        return None
    ancho = max([len(encabezado)] + [len(f) for f in filas_ok])
    encabezado = encabezado + [""] * (ancho - len(encabezado))
    filas_ok = [f + [""] * (ancho - len(f)) for f in filas_ok]
    df = pd.DataFrame(filas_ok, columns=_nombres_unicos(encabezado))
    df["Pagina_Origen"] = paginas
    return df


def convertir_numeros(df):
    """Convierte a número las columnas que son claramente numéricas (respeta códigos con ceros)."""
    df = df.copy()
    for col in df.columns:
        if col == "Pagina_Origen":
            continue
        vals = [v for v in df[col].astype(str) if v.strip()]
        if not vals:
            continue
        if all(re.fullmatch(r"\(?-?\s*(S/\.?|\$)?\s*\d{1,3}(,\d{3})*(\.\d+)?\)?|\(?-?\s*(S/\.?|\$)?\s*\d+(\.\d+)?\)?", v.strip()) for v in vals):
            if any(re.fullmatch(r"0\d+", v.strip()) for v in vals):
                continue                      # códigos tipo 00123: se dejan como texto
            def conv(v):
                v = v.strip()
                if not v:
                    return None
                neg = v.startswith("(") or v.startswith("-")
                n = float(re.sub(r"[^\d.]", "", v))
                n = -n if neg else n
                return int(n) if n == int(n) and "." not in v else n
            df[col] = [conv(v) for v in df[col].astype(str)]
        elif all(re.fullmatch(r"\d{1,2}/\d{1,2}/\d{4}", v.strip()) for v in vals):
            df[col] = pd.to_datetime(df[col].where(df[col].astype(str).str.strip() != ""), format="%d/%m/%Y", errors="coerce")
    return df


# ------------------------------------------------------------- OCR
def _configurar_tesseract():
    """Devuelve la ruta de Tesseract. En Windows lo busca junto al programa o en Archivos de programa."""
    try:
        import pytesseract
    except Exception:
        return None
    if sys.platform != "win32":
        return shutil.which("tesseract")
    candidatos = [shutil.which("tesseract")]
    bases = {os.path.dirname(sys.executable), getattr(sys, "_MEIPASS", None), _AQUI}
    candidatos += [os.path.join(b, "tesseract", "tesseract.exe") for b in bases if b]
    for var in ("ProgramFiles", "ProgramFiles(x86)"):
        if os.environ.get(var):
            candidatos.append(os.path.join(os.environ[var], "Tesseract-OCR", "tesseract.exe"))
    if os.environ.get("LOCALAPPDATA"):
        candidatos.append(os.path.join(os.environ["LOCALAPPDATA"], "Programs", "Tesseract-OCR", "tesseract.exe"))
    for c in candidatos:
        if c and os.path.isfile(c):
            pytesseract.pytesseract.tesseract_cmd = c
            datos = os.path.join(os.path.dirname(c), "tessdata")
            if os.path.isdir(datos):
                os.environ["TESSDATA_PREFIX"] = datos
            return c
    return None


def ocr_disponible():
    try:
        import pytesseract  # noqa: F401
    except Exception:
        return False, "Falta la librería pytesseract."
    if not _configurar_tesseract():
        if sys.platform == "win32":
            return False, ("Falta Tesseract OCR. Reinstale Cuadre de Inventario con su instalador, "
                           "o instale Tesseract (versión de UB Mannheim) con el idioma español.")
        return False, "Falta el programa Tesseract (OCR). Reinstale Cuadre de Inventario con el instalador .deb."
    return True, ""


def _idioma():
    import pytesseract
    try:
        langs = pytesseract.get_languages()
    except Exception:
        return "eng"
    if "spa" in langs and "eng" in langs:
        return "spa+eng"
    return "spa" if "spa" in langs else "eng"


def _deskew(img):
    """Corrige la ligera inclinación típica de una foto o de un escaneo torcido."""
    import numpy as np
    from PIL import Image
    try:
        peq = img.copy(); peq.thumbnail((800, 800))
        a = peq.point(lambda p: 255 if p < 160 else 0)

        def puntaje(ang):
            return np.asarray(a.rotate(float(ang), resample=Image.BILINEAR)).sum(axis=1).astype(float).var()
        mejor = max(np.arange(-5, 5.01, 0.5), key=puntaje)
        mejor = float(max(np.arange(mejor - 0.5, mejor + 0.51, 0.1), key=puntaje))
        if abs(mejor) >= 0.2:
            img = img.rotate(mejor, resample=Image.BICUBIC, expand=True, fillcolor=255)
    except Exception:
        pass
    return img


def _confianza(img):
    import pytesseract
    peq = img.copy(); peq.thumbnail((1100, 1100))
    d = pytesseract.image_to_data(peq, lang=_idioma(), config="--psm 6", output_type=pytesseract.Output.DICT)
    c = []
    for t, k in zip(d["text"], d["conf"]):
        try:
            k = float(k)
        except Exception:
            continue
        if k >= 0 and len((t or "").strip()) >= 2:
            c.append(k)
    return (sum(c) / len(c)) if c else 0.0


def _orientar(img):
    """Prueba 0/90/180/270°: endereza, borra líneas y se queda con la orientación que el OCR lee mejor."""
    mejor = None
    for ang in (0, 90, 180, 270):
        cand = img.rotate(ang, expand=True, fillcolor=255) if ang else img
        cand, rej = _quitar_lineas(_deskew(cand))
        c = _confianza(cand)
        if mejor is None or c > mejor[0] + 10:
            mejor = (c, cand, rej)
        if ang == 0 and c >= 70:
            break
    return mejor[1], mejor[2]


def _quitar_lineas(img):
    """Borra las líneas (bordes) de la tabla para que el OCR lea solo el texto."""
    import numpy as np
    from PIL import Image, ImageFilter
    a = np.asarray(img)
    fondo = int(np.percentile(a, 90))
    dark = a < np.median(a) * 0.6
    mv = np.asarray(Image.fromarray((dark * 255).astype("uint8")).filter(ImageFilter.MaxFilter(3))) > 0
    h, w = dark.shape

    def tramos(mask, minlen):
        out = np.zeros_like(mask)
        for i in range(mask.shape[0]):
            fila = mask[i]
            if fila.sum() < minlen:
                continue
            dif = np.diff(np.concatenate(([0], fila.astype(np.int8), [0])))
            for s0, e0 in zip(np.where(dif == 1)[0], np.where(dif == -1)[0]):
                if e0 - s0 >= minlen:
                    out[i, s0:e0] = True
        return out

    hor = tramos(mv, int(0.25 * w))
    ver = tramos(mv.T, int(0.05 * h)).T
    mascara = hor | ver

    def centros(indices):
        grupos, ult = [], None
        for i in indices:
            if ult is not None and i - ult <= 4:
                grupos[-1].append(i)
            else:
                grupos.append([i])
            ult = i
        return [sum(g) / len(g) for g in grupos]

    rejilla = (centros(np.where(ver.any(axis=0))[0]), centros(np.where(hor.any(axis=1))[0]))
    if not mascara.any():
        return img, rejilla
    m = np.asarray(Image.fromarray((mascara * 255).astype("uint8")).filter(ImageFilter.MaxFilter(5))) > 0
    out = np.array(img)
    out[m] = fondo
    return Image.fromarray(out), rejilla


def preparar_imagen(img):
    from PIL import ImageOps, ImageFilter, Image
    img = ImageOps.exif_transpose(img)           # fotos de celular giradas
    img = img.convert("L")
    img = ImageOps.autocontrast(img, cutoff=1)
    if img.width < 2000:
        f = min(3.0, 2000 / img.width)
        img = img.resize((int(img.width * f), int(img.height * f)), Image.LANCZOS)
    img, rejilla = _orientar(img)
    return img.filter(ImageFilter.UnsharpMask(radius=1.5, percent=120, threshold=3)), rejilla


def _en_banda(valor, lineas):
    for k in range(len(lineas) - 1):
        if lineas[k] <= valor <= lineas[k + 1]:
            return k
    return None


def ocr_a_filas(img, rejilla=None):
    """OCR de una imagen con tabla -> lista de filas (lista de celdas)."""
    import pytesseract
    d = pytesseract.image_to_data(img, lang=_idioma(), config="--psm 6", output_type=pytesseract.Output.DICT)
    palabras = []
    for i, t in enumerate(d["text"]):
        t = (t or "").strip().strip("|[]{}_—–=~`¦").strip()      # restos de líneas de la tabla
        if not any(ch.isalnum() for ch in t):
            continue
        try:
            conf = float(d["conf"][i])
        except Exception:
            conf = -1
        if t and conf >= 30:
            x, y, w, h = d["left"][i], d["top"][i], d["width"][i], d["height"][i]
            palabras.append((x, x + w, y + h / 2.0, h, t))
    if not palabras:
        return []
    xs, ys = rejilla if rejilla else ([], [])
    if len(xs) >= 3 and len(ys) >= 3:          # tabla con bordes: se usa la rejilla real
        celdas = {}
        alto0 = statistics.median(p[3] for p in palabras)
        for x0, x1, yc, h, t in palabras:
            f, c = _en_banda(yc, ys), _en_banda((x0 + x1) / 2.0, xs)
            if f is not None and c is not None:
                celdas.setdefault((f, c), []).append((x0, yc, t))

        def texto_celda(ws):                       # líneas de arriba abajo; en cada línea, de izquierda a derecha
            ws = sorted(ws, key=lambda w: w[1]); lineas = []
            for w in ws:
                if lineas and abs(w[1] - lineas[-1][0][1]) <= 0.6 * alto0:
                    lineas[-1].append(w)
                else:
                    lineas.append([w])
            return " ".join(w[2] for ln in lineas for w in sorted(ln, key=lambda w: w[0]))
        if celdas:
            return [[texto_celda(celdas.get((f, c), [])) for c in range(len(xs) - 1)] for f in range(len(ys) - 1)]
    # Tabla sin bordes: columnas por huecos verticales vacíos comunes a todas las filas
    alto = statistics.median(p[3] for p in palabras)
    palabras.sort(key=lambda p: p[2])
    lineas = []
    for p in palabras:
        if lineas and abs(p[2] - statistics.mean(q[2] for q in lineas[-1])) <= 0.6 * alto:
            lineas[-1].append(p)
        else:
            lineas.append([p])
    for ln in lineas:
        ln.sort(key=lambda p: p[0])

    def n_celdas(ln):
        n = 1
        for a0, b0 in zip(ln, ln[1:]):
            if b0[0] - a0[1] > 0.9 * alto:
                n += 1
        return n
    conteo = [n_celdas(ln) for ln in lineas]
    tipico = statistics.mode(conteo) if conteo else 0
    if tipico >= 2:                                    # fuera títulos y líneas sueltas; las columnas salen de las filas típicas
        base = [ln for ln, c in zip(lineas, conteo) if c >= max(2, tipico - 1)]
        minimo = max(2, tipico - 1)
        primera = next(i for i, c in enumerate(conteo) if c >= minimo)
        lineas = [ln for i, (ln, c) in enumerate(zip(lineas, conteo)) if i >= primera and c >= 2]
    else:
        base = lineas
    rangos = sorted((w[0], w[1]) for ln in base for w in ln)
    cols = []
    for x0, x1 in rangos:
        if cols and x0 - cols[-1][1] <= 0.9 * alto:
            cols[-1][1] = max(cols[-1][1], x1)
        else:
            cols.append([x0, x1])
    if not cols:
        return []
    filas = []
    for ln in lineas:
        fila = [""] * len(cols)
        for x0, x1, yc, h, txt in ln:
            cx = (x0 + x1) / 2.0
            j = next((k for k, (a0, b0) in enumerate(cols) if a0 <= cx <= b0), 0)
            fila[j] = (fila[j] + " " + txt).strip()
        filas.append(fila)
    return filas


# ------------------------------------------------------------- extracción
def extraer(ruta, modo="auto", progreso=None):
    """Devuelve (DataFrame | None, mensaje)."""
    avisar = progreso or (lambda m: None)
    ext = os.path.splitext(ruta)[1].lower()
    lista, uso_ocr, paginas_ocr = [], False, 0
    if ext == ".pdf":
        import pdfplumber
        with pdfplumber.open(ruta) as pdf:
            n = len(pdf.pages)
            for i, pag in enumerate(pdf.pages, 1):
                avisar(f"Leyendo página {i} de {n}…")
                tablas = []
                if modo != "ocr":
                    tablas = [t for t in pag.extract_tables() if t and any(any(c for c in r) for r in t)]
                    if not tablas and len(pag.chars) >= 20:
                        try:
                            t2 = pag.extract_tables({"vertical_strategy": "text", "horizontal_strategy": "text"})
                            tablas = [t for t in t2 if len(t) >= 3 and max(len(r) for r in t) >= 2]
                        except Exception:
                            tablas = []
                if not tablas and (modo == "ocr" or (modo == "auto" and len(pag.chars) < 20)):
                    ok, msg = ocr_disponible()
                    if not ok:
                        return None, msg
                    avisar(f"Aplicando OCR a la página {i} de {n}… (puede tardar)")
                    img, rej = preparar_imagen(pag.to_image(resolution=200).original)
                    filas = ocr_a_filas(img, rej)
                    if filas:
                        tablas, uso_ocr, paginas_ocr = [filas], True, paginas_ocr + 1
                lista += [(i, t) for t in tablas]
    elif ext in EXT_IMAGEN:
        ok, msg = ocr_disponible()
        if not ok:
            return None, msg
        from PIL import Image
        avisar("Aplicando OCR a la imagen… (puede tardar)")
        img, rej = preparar_imagen(Image.open(ruta))
        filas = ocr_a_filas(img, rej)
        lista, uso_ocr, paginas_ocr = ([(1, filas)] if filas else []), True, 1
    else:
        return None, "Formato no admitido. Use PDF o una foto (PNG, JPG, TIF, BMP, WEBP)."
    df = combinar_tablas(lista) if lista else None
    if df is None or df.empty:
        return None, "No se detectaron tablas. Si el documento es una foto o un escaneo, pruebe el modo «Escaneado o foto (OCR)»."
    msg = f"{len(df)} filas y {len(df.columns) - 1} columnas extraídas"
    if uso_ocr:
        msg += " con OCR: revise los datos, el reconocimiento puede tener errores de lectura"
    return df, msg + "."


def exportar_excel(df, ruta):
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    wb = Workbook(); ws = wb.active; ws.title = "DATOS EXTRAIDOS"
    lado = Side(style="thin", color="999999"); borde = Border(left=lado, right=lado, top=lado, bottom=lado)
    ws.append([str(c) for c in df.columns])
    for fila in df.itertuples(index=False):
        ws.append([None if (isinstance(v, float) and pd.isna(v)) or v is pd.NaT else (v.to_pydatetime() if hasattr(v, "to_pydatetime") else v) for v in fila])
    for c in ws[1]:
        c.font = Font(bold=True); c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for fila in ws.iter_rows():
        for c in fila:
            c.border = borde
            if hasattr(c.value, "year"):
                c.number_format = "DD/MM/YYYY"
            elif isinstance(c.value, float):
                c.number_format = "#,##0.00"
    for j, col in enumerate(df.columns, 1):
        largo = max([len(str(col))] + [len(str(v)) for v in df[col].head(300)])
        ws.column_dimensions[get_column_letter(j)].width = min(max(largo + 2, 8), 50)
    ws.freeze_panes = "A2"
    ws.page_setup.orientation = "landscape"; ws.page_setup.fitToWidth = 1; ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    wb.save(ruta)


# ------------------------------------------------------------- ventana gráfica
class VentanaExtractor:
    def __init__(self, app):
        import tkinter as tk
        from tkinter import ttk
        self.app, self.tk, self.ttk = app, tk, ttk
        self.df, self.ruta, self.hilo, self.resultado, self.progreso_msg = None, "", None, None, ""
        self.win = tk.Toplevel(app.root)
        self.win.title("Extraer tablas de PDF o foto a Excel")
        self.win.geometry("1060x680+60+30")
        self.win.minsize(900, 560)

        f1 = ttk.LabelFrame(self.win, text="1. Elegir el documento (PDF digital, PDF escaneado o foto)", padding=8)
        f1.pack(fill="x", padx=10, pady=(10, 5))
        ttk.Button(f1, text="Elegir PDF o foto…", width=24, command=self.elegir).grid(row=0, column=0, padx=5, pady=3)
        self.lbl_archivo = ttk.Label(f1, text="Ningún archivo seleccionado", foreground="gray")
        self.lbl_archivo.grid(row=0, column=1, sticky="w", padx=5)

        f2 = ttk.LabelFrame(self.win, text="2. Opciones", padding=8)
        f2.pack(fill="x", padx=10, pady=5)
        ttk.Label(f2, text="Tipo de documento:").grid(row=0, column=0, padx=5, sticky="e")
        self.cb_modo = ttk.Combobox(f2, values=list(MODOS), state="readonly", width=30)
        self.cb_modo.current(0)
        self.cb_modo.grid(row=0, column=1, padx=5)
        self.var_num = tk.BooleanVar(value=True)
        ttk.Checkbutton(f2, text="Convertir números y fechas", variable=self.var_num,
                        command=self.mostrar).grid(row=0, column=2, padx=15)
        ttk.Button(f2, text="▶ Extraer tablas", command=self.extraer).grid(row=0, column=3, padx=10)

        f3 = ttk.LabelFrame(self.win, text="3. Vista previa de los datos extraídos", padding=6)
        f3.pack(fill="both", expand=True, padx=10, pady=5)
        self.tree = ttk.Treeview(f3, show="headings", selectmode="browse")
        sy = ttk.Scrollbar(f3, orient="vertical", command=self.tree.yview)
        sx = ttk.Scrollbar(f3, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        self.tree.grid(row=0, column=0, sticky="nsew"); sy.grid(row=0, column=1, sticky="ns"); sx.grid(row=1, column=0, sticky="ew")
        f3.rowconfigure(0, weight=1); f3.columnconfigure(0, weight=1)

        f4 = ttk.Frame(self.win, padding=(10, 4)); f4.pack(fill="x")
        ttk.Button(f4, text="💾 Exportar a Excel", command=self.exportar).pack(side="left", padx=(0, 8))
        ttk.Button(f4, text="Usar como Sistema (Teórico)", command=lambda: self.usar("teorico")).pack(side="left", padx=(0, 8))
        ttk.Button(f4, text="Usar como Conteo Físico", command=lambda: self.usar("fisico")).pack(side="left", padx=(0, 8))
        ttk.Button(f4, text="Cerrar", command=self.win.destroy).pack(side="right")
        self.lbl_estado = ttk.Label(self.win, text="Elija un documento y pulse «Extraer tablas».", relief="sunken", anchor="w", padding=(8, 3))
        self.lbl_estado.pack(fill="x", side="bottom")

    def elegir(self):
        ruta = self.app._pedir_archivo("Seleccionar PDF o foto", "PDF y fotos", PATRONES_ARCHIVO)
        if ruta:
            self.ruta = ruta
            self.lbl_archivo.config(text=os.path.basename(ruta), foreground="black")
            self.lbl_estado.config(text="Documento elegido. Pulse «Extraer tablas».")

    def extraer(self):
        from tkinter import messagebox
        if not self.ruta:
            messagebox.showwarning("Falta el documento", "Primero elija un PDF o una foto.", parent=self.win)
            return
        if self.hilo and self.hilo.is_alive():
            return
        modo, ruta = MODOS[self.cb_modo.get()], self.ruta
        self.resultado, self.progreso_msg = None, "Extrayendo…"
        self.win.config(cursor="watch")

        def trabajo():
            try:
                self.resultado = extraer(ruta, modo, lambda m: setattr(self, "progreso_msg", m))
            except Exception as e:
                self.resultado = (None, f"No se pudo leer el documento: {e}")
        self.hilo = threading.Thread(target=trabajo, daemon=True)
        self.hilo.start()
        self._esperar()

    def _esperar(self):
        if self.hilo.is_alive():
            self.lbl_estado.config(text=self.progreso_msg)
            self.win.after(150, self._esperar)
            return
        self.win.config(cursor="")
        self.df, msg = self.resultado
        self.lbl_estado.config(text=msg)
        if self.df is None:
            from tkinter import messagebox
            messagebox.showwarning("Sin tablas", msg, parent=self.win)
        self.mostrar()

    def _datos(self):
        if self.df is None:
            return None
        return convertir_numeros(self.df) if self.var_num.get() else self.df

    def mostrar(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        df = self._datos()
        if df is None:
            self.tree["columns"] = ()
            return
        cols = [str(c) for c in df.columns]
        self.tree["columns"] = cols
        for c in cols:
            self.tree.heading(c, text=c)
            self.tree.column(c, width=min(max(len(c) * 11 + 20, 90), 360), anchor="w")
        for fila in df.head(500).itertuples(index=False):
            self.tree.insert("", "end", values=["" if (isinstance(v, float) and pd.isna(v)) or v is pd.NaT else (v.strftime("%d/%m/%Y") if hasattr(v, "strftime") else (f"{v:,.2f}" if isinstance(v, float) else v)) for v in fila])

    def exportar(self):
        from tkinter import messagebox
        df = self._datos()
        if df is None:
            messagebox.showwarning("Sin datos", "Primero extraiga las tablas de un documento.", parent=self.win)
            return
        base = os.path.splitext(os.path.basename(self.ruta))[0]
        ruta = self.app._pedir_guardado("Guardar tablas extraídas", f"{base}_extraido.xlsx")
        if not ruta:
            return
        try:
            exportar_excel(df, ruta)
        except Exception as e:
            messagebox.showerror("Error al guardar", f"No se pudo guardar el archivo:\n{e}", parent=self.win)
            return
        messagebox.showinfo("Exportado", f"Tabla guardada correctamente en:\n{ruta}", parent=self.win)

    def usar(self, destino):
        from tkinter import messagebox
        df = self._datos()
        if df is None:
            messagebox.showwarning("Sin datos", "Primero extraiga las tablas de un documento.", parent=self.win)
            return
        df = df.drop(columns=["Pagina_Origen"], errors="ignore")
        nombre = os.path.basename(self.ruta)
        (self.app._aplicar_teorico if destino == "teorico" else self.app._aplicar_fisico)(df, nombre)
        messagebox.showinfo("Listo", "Los datos se cargaron en la ventana principal.\nVerifique las columnas y pulse «Procesar y Cruzar Inventario».", parent=self.win)
        self.win.destroy()


def abrir(app):
    VentanaExtractor(app)
