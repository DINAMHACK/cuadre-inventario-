#!/bin/sh
# Construye dist/cuadre-inventario_<version>.deb a partir de src/ y packaging/.
# Requiere: dpkg-deb, unzip, pip (python3-pip) e internet (descarga las librerías pdfplumber, pdfminer.six, pypdfium2 y pytesseract).
set -e
cd "$(dirname "$0")/.."
VERSION=$(grep '^Version:' packaging/DEBIAN/control | cut -d' ' -f2)
RAIZ="build/cuadre-inventario_$VERSION"
rm -rf build && mkdir -p "$RAIZ" build/ruedas
cp -r packaging/DEBIAN packaging/usr "$RAIZ"/
mkdir -p "$RAIZ/opt/cuadre-inventario/vendor" "$RAIZ/opt/cuadre-inventario/ejemplos"
cp src/*.py src/icono.png "$RAIZ/opt/cuadre-inventario/"
cp ejemplos/* "$RAIZ/opt/cuadre-inventario/ejemplos/"
pip download pdfplumber==0.11.4 pdfminer.six==20231228 pypdfium2==4.30.0 pytesseract==0.3.13 \
    --no-deps --only-binary=:all: --platform manylinux2014_x86_64 --platform manylinux_2_17_x86_64 --platform any \
    --python-version 3.12 -d build/ruedas -q
for w in build/ruedas/*.whl; do unzip -q -o "$w" -x '*.dist-info/*' -d "$RAIZ/opt/cuadre-inventario/vendor"; done
find "$RAIZ" -type d -exec chmod 755 {} +; find "$RAIZ" -type f -exec chmod 644 {} +; chmod 755 "$RAIZ/usr/bin/cuadre-inventario" "$RAIZ/opt/cuadre-inventario/cuadre_inventario.py"
find "$RAIZ" -name __pycache__ -prune -exec rm -rf {} +
mkdir -p dist
dpkg-deb --root-owner-group --build "$RAIZ" "dist/cuadre-inventario_$VERSION.deb"
echo "Listo: dist/cuadre-inventario_$VERSION.deb"
