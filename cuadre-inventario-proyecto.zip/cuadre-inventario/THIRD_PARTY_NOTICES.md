# Librerías de terceros

El `.deb` incluye, sin modificarlas, estas librerías (descargadas de PyPI al construir el paquete). Cada una conserva su propia licencia; antes de redistribuir verifique los textos de licencia vigentes en sus páginas.

| Librería | Versión | Licencia (según su proyecto) |
|---|---|---|
| pdfplumber | 0.11.4 | MIT |
| pdfminer.six | 20231228 | MIT |
| pypdfium2 (incluye PDFium) | 4.30.0 | Apache-2.0 / BSD-3 |
| pytesseract | 0.3.13 | Apache-2.0 |

Del sistema (instaladas por `apt`, no incluidas): Tesseract OCR (Apache-2.0), pandas (BSD-3), openpyxl (MIT), Pillow (HPND), numpy (BSD-3).

## Solo en el instalador de Windows
Se incluyen además: Python y el empaquetador PyInstaller (GPL-2.0 con excepción para programas empaquetados), Tesseract OCR (Apache-2.0) con datos de idioma `spa` de tessdata_fast (Apache-2.0), y se usa Inno Setup (licencia propia, gratuita) para crear el instalador. Verifique las licencias vigentes antes de redistribuir.
