# Cuadre de Inventario / Kardex

Programa de escritorio para **Linux Mint** (64 bits) y **Windows 10/11** que:

1. **Cruza** el Excel del Sistema (kardex, SIGA, etc.) contra el Excel del Conteo Físico y marca ítems CONFORME / FALTANTE / SOBRANTE, con exportación a Excel con colores y fórmulas vivas.
2. **Extrae tablas** de PDF digitales, PDF escaneados y fotos (OCR) a Excel, y puede cargarlas directo en el cuadre.

100 % local: no envía datos a internet. Todo se usa con interfaz gráfica (sin terminal).

## Estructura

| Carpeta | Contenido |
|---|---|
| `src/` | Código fuente (`cuadre_inventario.py`, `extractor_tablas.py`) |
| `packaging/` | Archivos del paquete `.deb` (control, lanzador, ícono, acceso del menú) |
| `scripts/construir_deb.sh` | Construye el `.deb` desde `src/` (descarga las librerías incluidas) |
| `dist/` | `.deb` ya construido (versión 1.2) |
| `windows/` | Instalador de Windows (script de Inno Setup, requisitos, alternativa con `.bat`) |
| `.github/workflows/` | Construcción automática del instalador de Windows en GitHub Actions |
| `docs/` | Manuales de instalación y de usuario (PDF), uno para Linux Mint y otro para Windows |
| `ejemplos/` | Archivos de práctica **inventados** (sin datos reales) |
| `herramientas_manuales/` | Scripts y capturas usados para generar los manuales |

## Instalar (usuario final)
Doble clic en `dist/cuadre-inventario_1.2.deb` → «Instalar paquete». Ver `docs/Manual_Instalacion_Cuadre_Inventario.pdf`.

## Windows
El programa es el mismo código. En Windows se distribuye como instalador gráfico (`CuadreInventario_Setup_1.2.exe`, doble clic, sin permisos de administrador) que incluye Python, las librerías y Tesseract OCR en español.
El instalador se construye en GitHub: pestaña **Actions → Construir instalador de Windows → Run workflow**; al terminar, el `.exe` queda como *artifact* descargable (o se adjunta a una *Release*).
Alternativa sin instalador: `windows/Abrir_Cuadre_Inventario.bat` (requiere Python 3.10+ y Tesseract ya instalados).
**Estado:** el código quedó adaptado a Windows y se verificó el empaquetado con PyInstaller en Linux, pero **el instalador de Windows aún no se ha construido ni probado en un Windows real**.

## Construir el .deb
```
sh scripts/construir_deb.sh
```
Requiere `dpkg-deb`, `unzip`, `pip` e internet.

## Dependencias
Del sistema (las instala el `.deb`): python3-tk, pandas, openpyxl, xlrd, Pillow, numpy, cryptography, charset-normalizer, zenity, tesseract-ocr, tesseract-ocr-spa.
Incluidas dentro del `.deb` (carpeta `vendor/`): pdfplumber, pdfminer.six, pypdfium2, pytesseract. Ver `THIRD_PARTY_NOTICES.md`.

## Pruebas realizadas
Probado en Ubuntu 24.04 (base de Mint 22): instalación con `apt`, cuadre con los ejemplos y extracción de PDF digital, PDF escaneado y fotos. **Pendiente: prueba en un Linux Mint real** (y en Mint 21) y en Windows.

## Privacidad
No subir al repositorio padrones, oficios ni kardex reales, ni el archivo `cuadre_inventario_errores.log`.

## Licencia
Pendiente de elegir por el autor (no hay archivo LICENSE todavía).
