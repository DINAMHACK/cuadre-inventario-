; Instalador gráfico para Windows (Inno Setup). Se compila desde la carpeta raíz del proyecto:  iscc windows\installer.iss
#define AppVersion "1.2"

[Setup]
AppName=Cuadre de Inventario
AppVersion={#AppVersion}
AppPublisher=Augusto
DefaultDirName={autopf}\CuadreInventario
DefaultGroupName=Cuadre de Inventario
OutputDir=..\dist_windows
OutputBaseFilename=CuadreInventario_Setup_{#AppVersion}
SetupIconFile=icono.ico
UninstallDisplayIcon={app}\CuadreInventario.exe
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
; se instala solo para el usuario actual: no pide contraseña de administrador
PrivilegesRequired=lowest
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "Crear un acceso directo en el Escritorio"; GroupDescription: "Accesos directos:"

[Files]
Source: "..\dist\CuadreInventario\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs
Source: "..\ejemplos\*"; DestDir: "{app}\ejemplos"; Flags: recursesubdirs

[Icons]
Name: "{group}\Cuadre de Inventario"; Filename: "{app}\CuadreInventario.exe"
Name: "{autodesktop}\Cuadre de Inventario"; Filename: "{app}\CuadreInventario.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\CuadreInventario.exe"; Description: "Abrir Cuadre de Inventario"; Flags: nowait postinstall skipifsilent
