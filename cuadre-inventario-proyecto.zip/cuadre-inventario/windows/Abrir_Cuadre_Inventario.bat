@echo off
REM Alternativa sin instalador: requiere Python 3.10+ (marcar "Add Python to PATH") y Tesseract OCR instalados.
REM Doble clic: la primera vez instala las librerías y luego abre el programa.
cd /d "%~dp0\.."
python -c "import pandas, openpyxl, pdfplumber, pytesseract, xlrd" >nul 2>&1
if errorlevel 1 (
  echo Instalando librerias por unica vez, espere...
  python -m pip install -r windows\requirements.txt
)
start "" pythonw src\cuadre_inventario.py
