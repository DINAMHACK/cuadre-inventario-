import sys; sys.path.insert(0,"/home/claude/work")
import pdf as L                      # genera también los manuales de Linux
from pdf import *
import imgs_win as W
from imgs import ann
from PIL import Image

# ---------------------------------------------------------------- imágenes estilo Windows
AB=[("Ejemplo_Conteo_Fisico.xlsx","Hoja de cálculo de Microsoft Excel"),("Ejemplo_Sistema.xlsx","Hoja de cálculo de Microsoft Excel")]
PF=[("Ejemplo_Padron_Foto.jpg","Archivo JPG"),("Ejemplo_Padron_PDF.pdf","Documento PDF")]
LIST=(168,108,852,425)
def a(img,box,name): return ann(img,[box],name)
IW={}
IW["wfiles"]=a(W.explorer(),(180,77,900,520),"w_files_area"); IW["wfile"]=a(W.explorer(),W.WM["exe"],"w_file")
IW["ss1"]=a(W.smartscreen(1),W.WM["mas"],"w_ss1"); IW["ss2"]=a(W.smartscreen(2),W.WM["ejec"],"w_ss2")
for k,p,b in [("s_bien","bienvenida","sig"),("s_dest","destino","sig"),("s_menu","menu","sig"),("s_tar","tareas","chk"),("s_listo","listo","inst"),("s_prog","progreso","barra"),("s_fin","fin","fin")]:
    im=W.setup(p); IW[k]=a(im,W.WM[b],"w_"+k)
IW["ini1"]=a(W.inicio(None),W.WM["inicio"],"w_ini1")
IW["ini2"]=a(W.inicio("m"),W.WM["busca"],"w_ini2"); IW["ini3"]=a(W.inicio("m","Cuadre"),W.WM["busca"],"w_ini3"); IW["ini4"]=a(W.inicio("m","Cuadre"),W.WM["res"],"w_ini4")
IW["aj1"]=a(W.ajustes(1),W.WM["puntos"],"w_aj1"); IW["aj2"]=a(W.ajustes(2),W.WM["desinst"],"w_aj2")
# diálogos de la ventana principal y del extractor
IW["d_sis"]=a(W.dialogo("abrir",AB),LIST,"w_d_sis"); IW["d_sis_f"]=a(W.dialogo("abrir",AB,1,"Ejemplo_Sistema.xlsx"),W.WM["fila"],"w_d_sis_f"); IW["d_sis_ok"]=a(W.dialogo("abrir",AB,1,"Ejemplo_Sistema.xlsx"),W.WM["ok"],"w_d_sis_ok")
IW["d_fis"]=a(W.dialogo("abrir",AB),LIST,"w_d_fis"); IW["d_fis_f"]=a(W.dialogo("abrir",AB,0,"Ejemplo_Conteo_Fisico.xlsx"),W.WM["fila"],"w_d_fis_f"); IW["d_fis_ok"]=a(W.dialogo("abrir",AB,0,"Ejemplo_Conteo_Fisico.xlsx"),W.WM["ok"],"w_d_fis_ok")
IW["sv_n"]=a(W.dialogo("guardar",AB,None,"Cuadre_Inventario_Kardex.xlsx","Archivo Excel"),W.WM["nombre"],"w_sv_n"); IW["sv_ok"]=a(W.dialogo("guardar",AB,None,"Cuadre_Inventario_Kardex.xlsx","Archivo Excel"),W.WM["ok"],"w_sv_ok")
IW["x_d"]=a(W.dialogo("abrir",PF,None,"","PDF y fotos"),LIST,"w_x_d"); IW["x_d_f"]=a(W.dialogo("abrir",PF,1,"Ejemplo_Padron_PDF.pdf","PDF y fotos"),W.WM["fila"],"w_x_d_f")
MAPA={"u_dlg_sis":"d_sis","u_dlg_sis_f":"d_sis_f","u_dlg_ok":"d_sis_ok","u_dlg_fis":"d_fis","u_dlg_fis_f":"d_fis_f","u_dlg_fis_ok":"d_fis_ok",
      "u_sv_dlg":"sv_n","u_sv_ok":"sv_ok","x_dlg":"x_d","x_dlg_f":"x_d_f","desk":"ini1","menu_open":"ini2","menu_type":"ini3","menu_res":"ini4"}
for k,v in MAPA.items(): I[k]=IW[v]
for k,v in IW.items(): I["w_"+k]=v

L.COMPAT="Compatible con Windows 10 y 11 (64 bits)."
REF="Ilustración referencial: el aspecto exacto puede variar según su versión de Windows."; REAL=L.REAL
REAL_W="Captura real del programa (en Windows la barra de título y los avisos se ven con el estilo de Windows)."
SUST=[("<b>botón del menú</b> de Linux Mint","botón <b>Inicio</b> de Windows (el logotipo de Windows en la barra de tareas)"),
 ("Haga clic en la caja de búsqueda del menú.","Haga clic en la caja de búsqueda del menú Inicio."),
 ("Pulse <b>OK</b> (o <b>Aceptar</b>). El botón se activa al elegir el archivo.","Pulse <b>Abrir</b>."),
 ("Pulse <b>OK</b> (o <b>Aceptar</b>).","Pulse <b>Abrir</b>."),
 ("Pulse <b>OK</b> (o <b>Guardar</b>).","Pulse <b>Guardar</b>."),
 ("y pulse <b>OK</b>.","y pulse <b>Abrir</b>."),
 ("elija carpeta y nombre en el selector y pulse <b>OK</b>.","elija carpeta y nombre en la ventana «Guardar como» y pulse <b>Guardar</b>."),
 ("Se abre el selector para guardar. Escriba o confirme","Se abre la ventana «Guardar como». Escriba o confirme"),
 ("Se abre el selector de archivos. Ubique","Se abre la ventana «Abrir». Ubique"),
 ("Se abre otra vez el selector de archivos.","Se abre otra vez la ventana «Abrir»."),
 ("En el selector de archivos, ubique","En la ventana «Abrir», ubique")]
def tr(t):
    for x,y in SUST: t=t.replace(x,y)
    return t
def adapta(pasos):
    out=[]
    for tit,subs in pasos:
        ns=[]
        for t,k,c in subs:
            c = REF if k in MAPA else (REAL_W if c==REAL else c)
            ns.append((tr(t),k,c))
        out.append((tit,ns))
    return out
pu_w=adapta(L.pu)
intro_uw=list(L.intro_u)+[Spacer(1,.2*cm),Paragraph("<b>Nota para Windows:</b> las ventanas «Abrir» y «Guardar como», el menú Inicio y el instalador son ilustraciones referenciales; la ventana del programa y sus botones son capturas reales (tomadas en Linux, por eso la barra de título y los avisos pueden verse con el estilo de Windows). El funcionamiento y los pasos son los mismos.",L.SM)]
ex_uw=L.ex_u
# ---------------------------------------------------------------- manual de instalación de Windows
intro_iw=[Paragraph("Antes de empezar",L.H1),HRFlowable(width="100%",thickness=0.8,color=colors.black,spaceAfter=4),
 Paragraph("Este manual explica cómo instalar <b>Cuadre de Inventario / Kardex</b> en Windows 10 u 11 usando solo el ratón. No necesita instalar Python ni escribir comandos.",L.K),Spacer(1,.2*cm),
 Paragraph("<b>Qué necesita:</b>",L.K),
 Paragraph("1. El archivo instalador <b>CuadreInventario_Setup_1.2.exe</b>.<br/>2. Un equipo de 64 bits con Windows 10 u 11.<br/>3. No hace falta contraseña de administrador: se instala solo para su usuario. Tampoco necesita internet: el instalador ya incluye todo, incluido el lector de texto en imágenes (OCR) en español.",L.K),Spacer(1,.2*cm),
 Paragraph("<b>Nota sobre las imágenes:</b> las pantallas de este manual son ilustraciones referenciales del instalador de Windows; el aspecto exacto puede variar según su versión de Windows. La captura de la ventana del programa es real.",L.SM)]
pi_w=[("Ubicar el instalador",[
  ("Abra el <b>Explorador de archivos</b> y entre a la carpeta donde guardó el instalador (por ejemplo, <b>Descargas</b>).","w_wfiles",REF),
  ("Localice el archivo <b>CuadreInventario_Setup_1.2.exe</b>.","w_wfile",REF)]),
 ("Abrir el instalador",[
  ("Haga <b>doble clic</b> sobre <b>CuadreInventario_Setup_1.2.exe</b>.","w_wfile",REF),
  ("Si Windows muestra «Windows protegió su PC», es normal: el instalador todavía no tiene firma digital de un editor reconocido. Haga clic en <b>Más información</b>.","w_ss1",REF),
  ("Haga clic en <b>Ejecutar de todas formas</b>. Hágalo solo si el instalador lo recibió de una fuente de confianza.","w_ss2",REF)]),
 ("Instalar el programa",[
  ("En la pantalla de bienvenida, pulse <b>Siguiente</b>.","w_s_bien",REF),
  ("Deje la carpeta de destino que propone el asistente y pulse <b>Siguiente</b>.","w_s_dest",REF),
  ("Deje la carpeta del Menú Inicio y pulse <b>Siguiente</b>.","w_s_menu",REF),
  ("Marque <b>Crear un acceso directo en el Escritorio</b> si desea tener el ícono en el Escritorio, y pulse <b>Siguiente</b>.","w_s_tar",REF),
  ("Pulse <b>Instalar</b>.","w_s_listo",REF),
  ("Espere mientras se copian los archivos. La barra avanza sola.","w_s_prog",REF),
  ("Cuando termine, deje marcada <b>Abrir Cuadre de Inventario</b> y pulse <b>Finalizar</b>.","w_s_fin",REF)]),
 ("Comprobar que quedó instalado",[
  ("Si el programa no se abrió solo, haga clic en el botón <b>Inicio</b> de Windows.","w_ini1",REF),
  ("Haga clic en la caja de búsqueda.","w_ini2",REF),
  ("Escriba <b>Cuadre</b>.","w_ini3",REF),
  ("Haga clic en <b>Cuadre de Inventario</b>.","w_ini4",REF),
  ("Se abre la ventana del programa. La instalación terminó correctamente.","app0",REAL)]),
 ("Desinstalar (opcional)",[
  ("Abra <b>Configuración → Aplicaciones → Aplicaciones instaladas</b>, busque <b>Cuadre de Inventario</b> y haga clic en los tres puntos de su fila.","w_aj1",REF),
  ("Elija <b>Desinstalar</b> y confirme.","w_aj2",REF)])]
ex_iw=[Spacer(1,.4*cm),Paragraph("Si algo no funciona",L.H1),HRFlowable(width="100%",thickness=0.8,color=colors.black,spaceAfter=6),
 tabla([["Problema","Qué hacer"],
  ["Windows o el antivirus bloquea el instalador","Es porque el instalador no está firmado digitalmente. Use «Más información → Ejecutar de todas formas». Si su antivirus lo bloquea, consulte con quien administra el equipo antes de permitirlo."],
  ["No aparece «Cuadre de Inventario» en el Menú Inicio","Cierre y vuelva a abrir el menú, o reinicie la sesión de Windows."],
  ["Al extraer una foto aparece «Falta Tesseract OCR»","Vuelva a ejecutar el instalador (repara la instalación). Si persiste, informe del mensaje."],
  ["El programa no abre o aparece «Error inesperado»","Abra su carpeta de usuario (por ejemplo, C:\\Users\\SuNombre) y busque el archivo <b>cuadre_inventario_errores.log</b>. Envíelo para poder corregir el problema."],
  ["Prefiero no usar el instalador (personal técnico)","Existe la alternativa <b>Abrir_Cuadre_Inventario.bat</b>, que requiere tener instalados Python 3.10 o superior y Tesseract OCR. No se recomienda para el usuario final."]],[6.2*cm,10.8*cm])]
L.build("Manual_Instalacion_Windows_Cuadre_Inventario.pdf","Manual de Instalación (Windows)","Cuadre de Inventario / Kardex en Windows",intro_iw,pi_w,ex_iw)
L.build("Manual_Usuario_Windows_Cuadre_Inventario.pdf","Manual de Usuario (Windows)","Cuadre de Inventario / Kardex en Windows",intro_uw,pu_w,ex_uw)
print("PDFs Windows ok")
