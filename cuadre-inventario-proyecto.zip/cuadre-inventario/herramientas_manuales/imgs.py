from PIL import Image, ImageDraw, ImageFont, ImageChops
F="/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"; FB="/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
def ft(sz,b=False): return ImageFont.truetype(FB if b else F, sz)
RED=(220,30,30); GREEN=(135,167,82); S="/home/claude/shots/"; O="/home/claude/work/img/"

def autocrop_black(im,m=6):
    bb=ImageChops.difference(im,Image.new("RGB",im.size,(0,0,0))).getbbox()
    return im.crop((max(bb[0]-m,0),max(bb[1]-m,0),min(bb[2]+m,im.width),min(bb[3]+m,im.height)))

def ann(im, boxes, name, crop=False, offset=(0,0)):
    im=im.convert("RGB").copy(); d=ImageDraw.Draw(im)
    for i,b in enumerate(boxes,1):
        d.rectangle(b,outline=RED,width=4)
        if len(boxes)>1:
            cx,cy=b[0]-2,b[1]-2
            d.ellipse((cx-13,cy-13,cx+13,cy+13),fill=RED)
            d.text((cx,cy),str(i),font=ft(15,True),fill="white",anchor="mm")
    if crop: im=autocrop_black(im)
    im.save(O+name+".png"); return O+name+".png"

def real(shot, boxes, name, crop=True):
    return ann(Image.open(S+shot+".png"), boxes, name, crop=crop)

# ---------------------------------------------------------------- mocks Mint
def win(w,h,title):
    im=Image.new("RGB",(w,h),(255,255,255)); d=ImageDraw.Draw(im)
    d.rectangle((0,0,w-1,h-1),outline=(150,150,150))
    d.rectangle((0,0,w,34),fill=(233,233,233)); d.line((0,34,w,34),fill=(200,200,200))
    d.text((w//2,17),title,font=ft(13,True),fill=(60,60,60),anchor="mm")
    for i,c in enumerate([(120,120,120)]*3):
        d.ellipse((w-30-i*24,10,w-16-i*24,24),outline=c,width=2)
    return im,d

def btn(d,box,text,primary=False):
    d.rounded_rectangle(box,radius=5,fill=GREEN if primary else (238,238,238),outline=(120,140,80) if primary else (170,170,170))
    d.text(((box[0]+box[2])//2,(box[1]+box[3])//2),text,font=ft(13,True),fill="white" if primary else (50,50,50),anchor="mm")

def deb_icon(d,x,y,s=64):
    d.polygon([(x,y+s*0.25),(x+s*0.5,y),(x+s,y+s*0.25),(x+s*0.5,y+s*0.5)],fill=(214,160,90))
    d.polygon([(x,y+s*0.25),(x+s*0.5,y+s*0.5),(x+s*0.5,y+s),(x,y+s*0.75)],fill=(176,122,60))
    d.polygon([(x+s,y+s*0.25),(x+s*0.5,y+s*0.5),(x+s*0.5,y+s),(x+s,y+s*0.75)],fill=(150,100,45))

def doc_icon(d,x,y,col):
    d.rectangle((x+8,y,x+50,y+60),fill=(250,250,250),outline=(150,150,150)); d.rectangle((x+8,y,x+50,y+14),fill=col)
    for k in range(3): d.line((x+14,y+26+k*10,x+44,y+26+k*10),fill=(190,190,190),width=2)

M={}
def mock_files(selected):
    im,d=win(900,520,"Descargas")
    d.rectangle((0,35,900,76),fill=(245,245,245)); d.rounded_rectangle((200,42,600,70),radius=5,fill="white",outline=(190,190,190))
    d.text((215,56),"Inicio  >  Descargas",font=ft(13),fill=(70,70,70),anchor="lm")
    d.rectangle((0,77,190,520),fill=(244,244,244))
    for i,t in enumerate(["Inicio","Escritorio","Documentos","Descargas","Imágenes","Papelera"]):
        y=96+i*38
        if t=="Descargas": d.rectangle((6,y-14,184,y+16),fill=(214,226,190))
        d.text((44,y),t,font=ft(14,t=="Descargas"),fill=(50,50,50),anchor="lm"); d.rectangle((18,y-8,34,y+8),outline=(120,120,120))
    doc_icon(d,250,110,(200,60,60)); d.text((284,190),"Informe.pdf",font=ft(12),fill=(60,60,60),anchor="mm")
    doc_icon(d,430,110,(70,130,200)); d.text((464,190),"Foto.jpg",font=ft(12),fill=(60,60,60),anchor="mm")
    doc_icon(d,610,110,(120,120,120)); d.text((644,190),"notas.txt",font=ft(12),fill=(60,60,60),anchor="mm")
    box=(240,250,470,370)
    if selected: d.rounded_rectangle(box,radius=6,fill=(207,222,242),outline=(120,160,220))
    deb_icon(d,325,262,76)
    d.text((355,352),"cuadre-inventario_1.2.deb",font=ft(12,selected),fill=(40,40,40),anchor="mm")
    M["files_deb"]=box
    return im
def mock_gdebi(state):
    im,d=win(760,520,"Instalador de paquetes")
    deb_icon(d,28,52,56); d.text((100,64),"cuadre-inventario",font=ft(19,True),fill=(30,30,30),anchor="lm")
    d.text((100,92),"Cuadre de Inventario / Kardex (100 % local)",font=ft(13),fill=(80,80,80),anchor="lm")
    d.text((28,150),"Descripción",font=ft(13,True),fill=(40,40,40)); d.line((28,172,200,172),fill=GREEN,width=3)
    d.text((220,150),"Archivos incluidos",font=ft(13),fill=(110,110,110))
    d.rectangle((28,184,732,360),outline=(200,200,200))
    for i,t in enumerate(["Cruza el Excel del Sistema (teórico) contra el Excel del","Conteo Físico, detecta faltantes y sobrantes y exporta un acta","en Excel con colores semáforo y fórmulas vivas.","","Interfaz gráfica de escritorio. No requiere internet."]):
        d.text((42,198+i*24),t,font=ft(13),fill=(60,60,60))
    st={"listo":"Todas las dependencias se pueden instalar.","prog":"Instalando… por favor espere.","fin":"Instalación finalizada correctamente."}[state]
    d.text((28,386),"Estado:",font=ft(13,True),fill=(40,40,40)); d.text((92,386),st,font=ft(13),fill=(40,100,40) if state!="prog" else (60,60,60))
    if state=="prog":
        d.rounded_rectangle((28,420,732,442),radius=6,outline=(170,170,170),fill=(240,240,240)); d.rounded_rectangle((28,420,420,442),radius=6,fill=GREEN)
    btn(d,(470,460,590,496),"Cerrar"); 
    if state=="listo": btn(d,(604,460,732,496),"Instalar paquete",True); M["gd_install"]=(604,460,732,496)
    if state=="fin": d.ellipse((650,60,700,110),fill=GREEN); d.text((675,85),"✓",font=ft(30,True),fill="white",anchor="mm"); M["gd_close"]=(470,460,590,496)
    return im
def mock_auth():
    im,d=win(560,330,"Autenticación necesaria")
    d.ellipse((30,60,90,120),outline=(120,120,120),width=3); d.rectangle((44,84,76,112),fill=(120,120,120))
    d.text((110,66),"Se necesita autenticación para instalar",font=ft(14,True),fill=(30,30,30)); d.text((110,88),"software en el sistema.",font=ft(14,True),fill=(30,30,30))
    d.text((110,122),"Escriba su contraseña de usuario:",font=ft(13),fill=(80,80,80))
    d.rounded_rectangle((110,150,520,184),radius=5,fill="white",outline=(150,150,150)); d.text((124,167),"●●●●●●●●",font=ft(14),fill=(40,40,40),anchor="lm")
    btn(d,(280,262,390,298),"Cancelar"); btn(d,(402,262,520,298),"Autenticar",True)
    M["au_field"]=(110,150,520,184); M["au_btn"]=(402,262,520,298)
    return im
def desktop(menu=None, typed=""):
    im=Image.new("RGB",(900,560)); d=ImageDraw.Draw(im)
    for y in range(560): d.line((0,y,900,y),fill=(30,95+y//12,115+y//14))
    d.rectangle((0,520,900,560),fill=(32,32,32)); d.ellipse((8,524,44,556),fill=GREEN); d.text((26,540),"M",font=ft(18,True),fill="white",anchor="mm")
    d.text((870,540),"10:42",font=ft(13),fill="white",anchor="rm")
    M["menu_btn"]=(4,522,48,558)
    if menu:
        d.rounded_rectangle((8,130,600,514),radius=8,fill=(44,44,44))
        d.rectangle((8,130,56,514),fill=(36,36,36))
        for i in range(5): d.ellipse((20,150+i*50,44,174+i*50),outline=(150,150,150),width=2)
        for i,t in enumerate(["Todas las aplicaciones","Accesorios","Internet","Oficina","Sonido y vídeo","Administración"]):
            d.text((74,152+i*34),t,font=ft(13),fill=(215,215,215),anchor="lm")
        d.rounded_rectangle((70,478,590,506),radius=5,fill=(70,70,70),outline=(135,167,82))
        d.text((84,492),typed if typed else "Escriba para buscar…",font=ft(13),fill="white" if typed else (150,150,150),anchor="lm"); M["search"]=(70,478,590,506)
        if typed:
            row=(250,146,590,206); d.rounded_rectangle(row,radius=6,fill=(82,110,54)); M["result"]=row
            d.rounded_rectangle((260,154,300,198),radius=6,fill=(31,78,120)); d.rectangle((268,162,292,190),fill="white")
            for k,c in enumerate([(19,115,51),(197,34,31),(176,96,0)]): d.rectangle((270,166+k*8,290,170+k*8),fill=c)
            d.text((312,166),"Cuadre de Inventario",font=ft(14,True),fill="white",anchor="lm"); d.text((312,188),"Cruza el Excel del Sistema contra el Conteo Físico",font=ft(11),fill=(225,235,215),anchor="lm")
        if menu=="ctx":
            d.rounded_rectangle((400,182,590,300),radius=6,fill=(60,60,60),outline=(100,100,100))
            for i,t in enumerate(["Abrir","Añadir al escritorio","Añadir al panel","Desinstalar"]):
                y=198+i*26
                if t=="Desinstalar": d.rectangle((402,y-12,588,y+12),fill=(82,110,54)); M["uninst"]=(402,y-12,588,y+12)
                d.text((414,y),t,font=ft(13),fill="white",anchor="lm")
    return im
