from PIL import Image, ImageDraw
from imgs import ft, ann, O, RED
BLUE=(0,103,192); GREY=(243,243,243)
WM={}
def wwin(w,h,title,bg=(255,255,255)):
    im=Image.new("RGB",(w,h),bg); d=ImageDraw.Draw(im)
    d.rectangle((0,0,w-1,h-1),outline=(140,140,140)); d.rectangle((0,0,w,32),fill=(240,240,240))
    d.text((12,16),title,font=ft(12),fill=(30,30,30),anchor="lm")
    d.text((w-100,16),"—",font=ft(14),fill=(40,40,40),anchor="mm"); d.rectangle((w-62,10,w-52,20),outline=(40,40,40)); d.text((w-18,16),"✕",font=ft(13),fill=(40,40,40),anchor="mm")
    return im,d
def wbtn(d,box,text,primary=False):
    d.rounded_rectangle(box,radius=4,fill=BLUE if primary else (253,253,253),outline=(0,80,160) if primary else (170,170,170))
    d.text(((box[0]+box[2])//2,(box[1]+box[3])//2),text,font=ft(12,primary),fill="white" if primary else (30,30,30),anchor="mm")
def exe_icon(d,x,y,s=60):
    d.rounded_rectangle((x,y,x+s,y+s),radius=8,fill=(31,78,120)); d.rectangle((x+14,y+12,x+s-14,y+s-12),fill="white")
    for k,c in enumerate([(19,115,51),(197,34,31),(176,96,0)]): d.rectangle((x+18,y+17+k*10,x+s-18,y+22+k*10),fill=c)

def explorer():
    im,d=wwin(900,520,"Descargas")
    d.rectangle((0,33,900,76),fill=GREY); d.rounded_rectangle((190,40,640,69),radius=4,fill="white",outline=(200,200,200)); d.text((205,55),"Este equipo  >  Descargas",font=ft(12),fill=(70,70,70),anchor="lm")
    d.rectangle((0,77,180,520),fill=(250,250,250))
    for i,t in enumerate(["Inicio","Escritorio","Descargas","Documentos","Imágenes"]):
        y=100+i*36
        if t=="Descargas": d.rectangle((6,y-14,174,y+14),fill=(220,232,248))
        d.text((40,y),t,font=ft(13,t=="Descargas"),fill=(40,40,40),anchor="lm"); d.rectangle((16,y-7,30,y+7),outline=(110,110,110))
    for k,(n,c) in enumerate([("Informe.pdf",(200,60,60)),("Foto.jpg",(70,130,200)),("notas.txt",(120,120,120))]):
        x=230+k*180; d.rectangle((x+8,110,x+50,170),fill="white",outline=(150,150,150)); d.rectangle((x+8,110,x+50,124),fill=c); d.text((x+29,190),n,font=ft(12),fill=(60,60,60),anchor="mm")
    box=(230,250,500,350); d.rounded_rectangle(box,radius=5,fill=(205,224,247),outline=(120,160,220)); exe_icon(d,330,260,56)
    d.text((365,332),"CuadreInventario_Setup_1.2.exe",font=ft(11,True),fill=(30,30,30),anchor="mm"); WM["exe"]=box
    return im
def smartscreen(paso):
    im,d=wwin(640,420,"Windows protegió su PC",bg=(0,90,158)); d.rectangle((0,0,640,32),fill=(0,70,130)); d.text((12,16),"Windows protegió su PC",font=ft(12),fill="white",anchor="lm")
    d.text((40,70),"Windows protegió su PC",font=ft(24,True),fill="white")
    d.text((40,125),"Microsoft Defender SmartScreen impidió el inicio de una aplicación",font=ft(13),fill="white"); d.text((40,146),"desconocida. Ejecutar esta aplicación podría poner en riesgo su PC.",font=ft(13),fill="white")
    d.text((40,185),"Aplicación: CuadreInventario_Setup_1.2.exe",font=ft(12),fill=(220,235,250)); d.text((40,206),"Editor: Editor desconocido",font=ft(12),fill=(220,235,250))
    if paso==1:
        d.text((40,250),"Más información",font=ft(13,True),fill="white"); d.line((40,268,150,268),fill="white"); WM["mas"]=(34,242,160,276)
        wbtn(d,(470,360,600,396),"No ejecutar",False)
    else:
        wbtn(d,(300,360,460,396),"Ejecutar de todas formas",False); WM["ejec"]=(300,360,460,396); wbtn(d,(476,360,606,396),"No ejecutar",True)
    return im
def setup(pagina):
    im,d=wwin(620,470,"Instalar - Cuadre de Inventario"); d.rectangle((1,33,619,92),fill="white"); d.line((0,92,620,92),fill=(200,200,200))
    titulos={"bienvenida":("Bienvenido al asistente de instalación de Cuadre de Inventario",""),
             "destino":("Seleccione la carpeta de destino","¿Dónde debe instalarse Cuadre de Inventario?"),
             "menu":("Seleccione la carpeta del Menú Inicio","¿Dónde deben colocarse los accesos directos del programa?"),
             "tareas":("Seleccione las tareas adicionales","¿Qué tareas adicionales deben realizarse?"),
             "listo":("Listo para instalar","Todo está listo para iniciar la instalación."),
             "progreso":("Instalando","Espere mientras se instala Cuadre de Inventario en su equipo."),
             "fin":("Completando la instalación","")}
    t,s=titulos[pagina]; d.text((24,50 if s else 62),t,font=ft(14,True),fill=(20,20,20)); 
    if s: d.text((24,74),s,font=ft(11),fill=(90,90,90))
    d.rectangle((24,112,596,380),fill="white")
    body={"bienvenida":["Este programa instalará Cuadre de Inventario 1.2 en su equipo.","","Se recomienda cerrar las demás aplicaciones antes de continuar.","","Pulse Siguiente para continuar."],
          "destino":["Cuadre de Inventario se instalará en la siguiente carpeta.","Para continuar, pulse Siguiente."],
          "menu":["Los accesos directos se crearán en la siguiente carpeta del Menú Inicio.","Para continuar, pulse Siguiente."],
          "listo":["Pulse Instalar para continuar con la instalación.","","Carpeta de destino:","   C:\\Users\\Usuario\\AppData\\Local\\Programs\\CuadreInventario","","Carpeta del Menú Inicio:","   Cuadre de Inventario"],
          "progreso":["Extrayendo archivos..."],"fin":["Cuadre de Inventario se instaló en su equipo.","","Pulse Finalizar para salir del asistente."]}.get(pagina,[])
    for i,l in enumerate(body): d.text((30,120+i*22),l,font=ft(12),fill=(40,40,40))
    if pagina=="destino": d.rounded_rectangle((30,170,480,198),radius=3,fill="white",outline=(150,150,150)); d.text((38,184),"C:\\Users\\Usuario\\AppData\\Local\\Programs\\CuadreInventario",font=ft(10),fill=(30,30,30),anchor="lm"); wbtn(d,(490,170,590,198),"Examinar..."); WM["ruta"]=(30,170,480,198)
    if pagina=="menu": d.rounded_rectangle((30,170,480,198),radius=3,fill="white",outline=(150,150,150)); d.text((38,184),"Cuadre de Inventario",font=ft(12),fill=(30,30,30),anchor="lm")
    if pagina=="tareas":
        d.text((30,125),"Accesos directos:",font=ft(12,True),fill=(40,40,40)); d.rectangle((34,152,50,168),outline=(60,60,60),width=2); d.line((37,160,42,165),fill=BLUE,width=3); d.line((42,165,49,154),fill=BLUE,width=3)
        d.text((60,160),"Crear un acceso directo en el Escritorio",font=ft(12),fill=(30,30,30),anchor="lm"); WM["chk"]=(30,148,380,172)
    if pagina=="progreso": d.rounded_rectangle((30,160,590,182),radius=3,outline=(150,150,150),fill=(235,235,235)); d.rectangle((31,161,360,181),fill=(6,176,37)); WM["barra"]=(30,160,590,182)
    if pagina=="fin": d.rectangle((34,230,50,246),outline=(60,60,60),width=2); d.line((37,238,42,243),fill=BLUE,width=3); d.line((42,243,49,232),fill=BLUE,width=3); d.text((60,238),"Abrir Cuadre de Inventario",font=ft(12),fill=(30,30,30),anchor="lm")
    d.line((0,400,620,400),fill=(210,210,210)); d.rectangle((1,401,619,468),fill=GREY)
    if pagina in ("destino","menu","tareas","listo"): wbtn(d,(300,418,400,450),"< Atrás")
    if pagina in ("bienvenida","destino","menu","tareas"): wbtn(d,(412,418,512,450),"Siguiente >",True); WM["sig"]=(412,418,512,450)
    if pagina=="listo": wbtn(d,(412,418,512,450),"Instalar",True); WM["inst"]=(412,418,512,450)
    if pagina=="fin": wbtn(d,(500,418,600,450),"Finalizar",True); WM["fin"]=(500,418,600,450)
    if pagina!="fin" and pagina!="progreso": wbtn(d,(524,418,600,450),"Cancelar")
    return im
def inicio(estado,typed=""):
    im=Image.new("RGB",(900,560),(35,95,160)); d=ImageDraw.Draw(im)
    for y in range(560): d.line((0,y,900,y),fill=(20+y//14,70+y//10,150+y//12))
    d.rectangle((0,516,900,560),fill=(236,236,240)); 
    for k in range(4): d.rectangle((424+(k%2)*16,526+(k//2)*16,438+(k%2)*16,540+(k//2)*16),fill=BLUE)
    WM["inicio"]=(416,520,460,556); d.text((880,538),"10:42",font=ft(11),fill=(30,30,30),anchor="rm")
    if estado:
        d.rounded_rectangle((250,60,650,508),radius=10,fill=(243,243,247),outline=(200,200,205))
        d.rounded_rectangle((270,78,630,112),radius=17,fill="white",outline=(150,150,150) if not typed else BLUE,width=2)
        d.text((290,95),typed if typed else "Escribe aquí para buscar",font=ft(12),fill=(30,30,30) if typed else (120,120,120),anchor="lm"); WM["busca"]=(268,76,632,114)
        if typed:
            d.text((274,140),"Mejor coincidencia",font=ft(12,True),fill=(40,40,40))
            r=(270,162,630,226); d.rounded_rectangle(r,radius=6,fill=(220,232,248),outline=(120,160,220)); WM["res"]=r
            exe_icon(d,282,170,48); d.text((344,184),"Cuadre de Inventario",font=ft(13,True),fill=(20,20,20),anchor="lm"); d.text((344,206),"Aplicación",font=ft(11),fill=(90,90,90),anchor="lm")
        else:
            d.text((274,140),"Anclado",font=ft(12,True),fill=(40,40,40))
            for i in range(12): d.rounded_rectangle((276+(i%6)*58,168+(i//6)*70,316+(i%6)*58,208+(i//6)*70),radius=8,fill=(200,205,215))
    return im
def dialogo(modo,archivos,sel=None,nombre="",filtro="Archivos Excel"):
    im,d=wwin(860,520,"Abrir" if modo=="abrir" else "Guardar como")
    d.rectangle((0,33,860,74),fill=GREY); d.rounded_rectangle((170,40,640,68),radius=4,fill="white",outline=(200,200,200)); d.text((184,54),"Este equipo  >  Documentos",font=ft(12),fill=(70,70,70),anchor="lm")
    d.rectangle((0,75,160,430),fill=(250,250,250))
    for i,t in enumerate(["Escritorio","Descargas","Documentos","Imágenes"]):
        y=96+i*34
        if t=="Documentos": d.rectangle((4,y-13,156,y+13),fill=(220,232,248))
        d.text((34,y),t,font=ft(12,t=="Documentos"),fill=(40,40,40),anchor="lm"); d.rectangle((12,y-6,24,y+6),outline=(110,110,110))
    d.text((176,92),"Nombre",font=ft(11),fill=(90,90,90)); d.text((520,92),"Fecha de modificación",font=ft(11),fill=(90,90,90)); d.text((690,92),"Tipo",font=ft(11),fill=(90,90,90)); d.line((170,104,850,104),fill=(225,225,225))
    for i,(n,tp) in enumerate(archivos):
        y=124+i*30
        if sel==i: d.rectangle((170,y-12,850,y+14),fill=(205,224,247)); WM["fila"]=(168,y-13,852,y+15)
        d.rectangle((178,y-8,192,y+8),outline=(100,100,100)); d.text((202,y),n,font=ft(12),fill=(30,30,30),anchor="lm"); d.text((520,y),"14/11/2026 10:40",font=ft(11),fill=(80,80,80),anchor="lm"); d.text((690,y),tp,font=ft(11),fill=(80,80,80),anchor="lm")
    d.rectangle((0,430,860,520),fill=GREY)
    d.text((24,452),"Nombre de archivo:",font=ft(12),fill=(40,40,40),anchor="lm"); d.rounded_rectangle((170,438,620,466),radius=3,fill="white",outline=(150,150,150)); WM["nombre"]=(168,436,622,468)
    d.text((180,452),nombre,font=ft(12),fill=(20,20,20),anchor="lm")
    d.rounded_rectangle((630,438,720,466),radius=3,fill="white",outline=(150,150,150)); d.text((640,452),filtro,font=ft(10),fill=(40,40,40),anchor="lm")
    ok="Abrir" if modo=="abrir" else "Guardar"
    wbtn(d,(630,478,730,506),ok,True); WM["ok"]=(630,478,730,506); wbtn(d,(742,478,842,506),"Cancelar")
    return im
def ajustes(estado):
    im,d=wwin(860,520,"Configuración  >  Aplicaciones  >  Aplicaciones instaladas")
    d.text((30,64),"Aplicaciones instaladas",font=ft(18,True),fill=(20,20,20)); d.rounded_rectangle((30,100,830,132),radius=4,fill="white",outline=(170,170,170)); d.text((44,116),"Buscar aplicaciones",font=ft(12),fill=(120,120,120),anchor="lm")
    for i,n in enumerate(["Cuadre de Inventario","LibreOffice","Microsoft Edge"]):
        y=150+i*62; fila=(30,y,830,y+56); d.rectangle(fila,fill=(252,252,252),outline=(225,225,225)); d.text((84,y+20),n,font=ft(13,True),fill=(20,20,20),anchor="lm"); d.text((84,y+40),"Versión 1.2" if i==0 else "",font=ft(11),fill=(100,100,100),anchor="lm"); d.rectangle((44,y+14,68,y+38),fill=(31,78,120) if i==0 else (160,160,160))
        d.text((800,y+28),"...",font=ft(18,True),fill=(40,40,40),anchor="mm")
        if i==0: WM["app"]=fila; WM["puntos"]=(780,y+10,820,y+46)
    if estado==2:
        d.rounded_rectangle((640,196,830,262),radius=6,fill="white",outline=(190,190,190)); d.text((660,214),"Modificar",font=ft(12),fill=(100,100,100),anchor="lm"); d.rectangle((642,226,828,252),fill=(220,232,248)); d.text((660,239),"Desinstalar",font=ft(12,True),fill=(20,20,20),anchor="lm"); WM["desinst"]=(642,226,828,252)
    return im
