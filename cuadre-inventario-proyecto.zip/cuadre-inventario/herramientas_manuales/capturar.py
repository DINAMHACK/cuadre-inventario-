import os, sys, subprocess
sys.path.insert(0, "/opt/cuadre-inventario")
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import cuadre_inventario as ci

OUT = "/home/claude/shots"
EJ = "/opt/cuadre-inventario/ejemplos"
wm = subprocess.Popen(["openbox"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
import time; time.sleep(2)
root = tk.Tk()
st = ttk.Style(); st.theme_use("clam")
root.geometry("1180x720+40+20")
app = ci.CuadreInventarioApp(root)
root.update()

def shot(name, crop="1240x760+0+0"):
    root.update(); root.update_idletasks()
    subprocess.run(["import", "-window", "root", "-crop", crop, "+repage", f"{OUT}/{name}.png"], check=True)

def autocrop(path):
    from PIL import Image, ImageChops
    im = Image.open(path).convert("RGB")
    bg = Image.new("RGB", im.size, (0, 0, 0))
    bb = ImageChops.difference(im, bg).getbbox()
    if bb:
        im.crop((max(bb[0]-6,0), max(bb[1]-6,0), min(bb[2]+6, im.width), min(bb[3]+6, im.height))).save(path)

def shot_dialog(name, fn):
    """Abre el diálogo real, lo captura y lo cierra."""
    def cap():
        shot(name, "1600x1000+0+0"); autocrop(f"{OUT}/{name}.png")
        subprocess.run(["pkill","-x","zenity"])
    root.after(2500, cap)
    fn()

shot("01_ventana_inicial")

# Diálogo de abrir (sistema)
orig_open, orig_save = filedialog.askopenfilename, filedialog.asksaveasfilename
shot_dialog("02_dialogo_abrir", app.cargar_teorico)

# Carga real del sistema
def abrir_sistema(**k): return f"{EJ}/Ejemplo_Sistema.xlsx"
def abrir_fisico(**k): return f"{EJ}/Ejemplo_Conteo_Fisico.xlsx"
shot_dialog("02b_dialogo_fisico", app.cargar_fisico)
app._pedir_excel = lambda t: f'{EJ}/Ejemplo_Sistema.xlsx'
app.cargar_teorico(); shot("03_sistema_cargado")
app._pedir_excel = lambda t: f'{EJ}/Ejemplo_Conteo_Fisico.xlsx'
app.cargar_fisico(); shot("04_fisico_cargado")

# ajustar columnas de precio ya autodetectada; procesar
app.procesar_cuadre(); shot("05_resultado")
app.cb_filtro.set("FALTANTE"); app.actualizar_tabla(); shot("06_filtro_faltante")
app.cb_filtro.set("TODOS"); app.actualizar_tabla()

# diálogo de guardar
open("/home/claude/test/Documentos/Cuadre_Inventario_Kardex.xlsx","w").close()
shot_dialog("07_dialogo_guardar", app.exportar_excel)
app._pedir_guardado = lambda t, n: "/home/claude/test/Documentos/Cuadre_Inventario_Kardex.xlsx"
def cap_msg():
    shot("08_exportado")
    root.tk.eval(".__tk__messagebox.ok invoke")
root.after(1500, cap_msg)
app.exportar_excel()
app.limpiar_todo(); shot("09_limpiar")
wm.terminate(); print("OK")
