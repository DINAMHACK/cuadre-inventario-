import sys; sys.path.insert(0,"/home/claude/work")
from imgs import *
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image as RLImage, KeepTogether, PageBreak, Table, TableStyle, HRFlowable
from reportlab.lib import colors
pdfmetrics.registerFont(TTFont("DV",F)); pdfmetrics.registerFont(TTFont("DVB",FB))
from reportlab.pdfbase.pdfmetrics import registerFontFamily
registerFontFamily("DV",normal="DV",bold="DVB",italic="DV",boldItalic="DVB")

# ------------------------------------------------ cajas sobre capturas reales (coordenadas de la captura original)
B=dict(btn_sis=(66,86,352,118),btn_fis=(66,126,352,158),lbl_sis=(358,90,700,114),lbl_fis=(358,130,700,154),
       map_sis=(60,214,1204,242),map_fis=(60,243,962,270),chk=(64,274,492,300),
       btn_proc=(50,316,274,352),btn_exp=(278,316,494,352),btn_lim=(498,316,617,352),
       filtro=(638,318,877,350),resumen=(890,320,1210,348),
       falt=(52,390,1196,429),sobr=(52,429,1196,469),conf=(52,469,1196,529),tabla=(52,360,1210,712),status=(42,732,1222,758),
       ok_msg=(572,455,692,493))
D_OK=(1500,931,1554,971); D_NAME=(763,562,1565,598); D_LIST=(852,647,1561,874)
D_FIL_SIS=(854,706,1561,738); D_FIL_FIS=(854,673,1561,705)
def dlg(shot,boxes,name):
    x0,y0=708,(538 if shot.startswith("07") else 572)
    im=Image.open(S+shot+".png").convert("RGB").crop((x0,y0,1566,986))
    return ann(im,[(b[0]-x0,b[1]-y0,b[2]-x0,b[3]-y0) for b in boxes],name)

# ------------------------------------------------ imágenes
I={}
I["files0"]=ann(mock_files(False),[M.get("files_deb",(240,250,470,370))],"files0") if False else None
fi=mock_files(True); I["files"]=ann(fi,[M["files_deb"]],"i_files")
I["files_plain"]=ann(mock_files(False),[(190,77,900,520)],"i_files_area")
I["gd_listo"]=ann(mock_gdebi("listo"),[(28,184,732,360)],"i_gd_desc")
I["gd_btn"]=ann(mock_gdebi("listo"),[M["gd_install"]],"i_gd_btn")
mock_auth(); I["au_pass"]=ann(mock_auth(),[M["au_field"]],"i_au_pass"); I["au_btn"]=ann(mock_auth(),[M["au_btn"]],"i_au_btn")
I["gd_prog"]=ann(mock_gdebi("prog"),[(28,420,732,442)],"i_gd_prog")
I["gd_fin"]=ann(mock_gdebi("fin"),[(28,376,732,398)],"i_gd_fin"); I["gd_close"]=ann(mock_gdebi("fin"),[M["gd_close"]],"i_gd_close")
desktop(); I["desk"]=ann(desktop(),[M["menu_btn"]],"i_desk")
desktop("m"); I["menu_open"]=ann(desktop("m"),[M["search"]],"i_menu_open")
I["menu_type"]=ann(desktop("m","Cuadre"),[M["search"]],"i_menu_type")
I["menu_res"]=ann(desktop("m","Cuadre"),[M["result"]],"i_menu_res")
desktop("ctx","Cuadre"); I["ctx"]=ann(desktop("ctx","Cuadre"),[M["result"]],"i_ctx_row"); I["ctx_u"]=ann(desktop("ctx","Cuadre"),[M["uninst"]],"i_ctx_u")

R=lambda shot,boxes,name,crop=True: real(shot,boxes,name,crop)
I["app0"]=R("01_ventana_inicial",[(40,20,1220,740)],"i_app0")
I["u_btn_sis"]=R("01_ventana_inicial",[B["btn_sis"]],"u_btn_sis")
I["u_dlg_sis"]=dlg("02_dialogo_abrir",[D_LIST],"u_dlg_sis")
I["u_dlg_sis_f"]=dlg("02_dialogo_abrir",[D_FIL_SIS],"u_dlg_sis_f") 
I["u_dlg_ok"]=dlg("02_dialogo_abrir",[D_OK],"u_dlg_ok")
I["u_lbl_sis"]=R("03_sistema_cargado",[B["lbl_sis"]],"u_lbl_sis")
I["u_map_sis"]=R("03_sistema_cargado",[B["map_sis"]],"u_map_sis")
I["u_btn_fis"]=R("03_sistema_cargado",[B["btn_fis"]],"u_btn_fis")
I["u_dlg_fis"]=dlg("02b_dialogo_fisico",[D_LIST],"u_dlg_fis")
I["u_dlg_fis_f"]=dlg("02b_dialogo_fisico",[D_FIL_FIS],"u_dlg_fis_f")
I["u_dlg_fis_ok"]=dlg("02b_dialogo_fisico",[D_OK],"u_dlg_fis_ok")
I["u_lbl_fis"]=R("04_fisico_cargado",[B["lbl_fis"]],"u_lbl_fis")
I["u_map_fis"]=R("04_fisico_cargado",[B["map_fis"]],"u_map_fis")
I["u_chk"]=R("04_fisico_cargado",[B["chk"]],"u_chk")
I["u_maps"]=R("04_fisico_cargado",[B["map_sis"],B["map_fis"]],"u_maps")
I["u_proc"]=R("04_fisico_cargado",[B["btn_proc"]],"u_proc")
I["u_res"]=R("05_resultado",[B["resumen"]],"u_res")
I["u_rows"]=R("05_resultado",[B["falt"],B["sobr"],B["conf"]],"u_rows")
I["u_filtro"]=R("05_resultado",[B["filtro"]],"u_filtro")
I["u_filtro2"]=R("06_filtro_faltante",[B["filtro"]],"u_filtro2")
I["u_falt"]=R("06_filtro_faltante",[(52,390,1196,429)],"u_falt")
I["u_filtro3"]=R("05_resultado",[B["filtro"],B["resumen"]],"u_filtro3")
I["u_exp"]=R("05_resultado",[B["btn_exp"]],"u_exp")
I["u_sv_dlg"]=dlg("07_dialogo_guardar",[D_NAME],"u_sv_name")
I["u_sv_ok"]=dlg("07_dialogo_guardar",[D_OK],"u_sv_ok")
I["u_ok"]=R("08_exportado",[B["ok_msg"]],"u_ok")
I["u_xls"]=ann(Image.open(S+"10_excel_exportado.png"),[(10,80,1233,121),(10,121,1233,185),(10,185,1233,241)] if False else [(12,12,1231,52)],"u_xls",crop=False)
I["u_xls2"]=ann(Image.open(S+"10_excel_exportado.png"),[(12,222,1231,243)],"u_xls2")
I["u_lim"]=R("05_resultado",[B["btn_lim"]],"u_lim")
I["u_lim2"]=R("09_limpiar",[B["status"]],"u_lim2")

# ------------- nueva función: extraer tablas
E=dict(elegir=(30,70,266,106),lbl=(270,74,520,102),modo=(176,162,472,192),chk=(486,164,698,192),extraer=(714,158,844,196),
       tabla=(24,242,1036,610),estado=(8,678,1068,706),exp=(14,638,161,676),sis=(165,638,377,676),fis=(380,638,555,676),ok18=(480,412,596,446))
def crop_ext(shot, boxes, name):
    return ann(Image.open(S+shot+".png"), boxes, name)
I["x_btn"]=R("11_principal_boton",[(906,104,1196,140)],"x_btn")
I["x_vacia"]=crop_ext("12_extractor_vacio",[(2,2,1070,712)],"x_vacia")
I["x_elegir"]=crop_ext("12_extractor_vacio",[E["elegir"]],"x_elegir")
_d=Image.open(S+"13_dialogo_pdf.png").convert("RGB"); _x0,_y0=660,552; _dc=_d.crop((_x0,_y0,_d.width,_d.height))
def dx(boxes,name): return ann(_dc,[(b[0]-_x0,b[1]-_y0,b[2]-_x0,b[3]-_y0) for b in boxes],name)
I["x_dlg"]=dx([(812,652,1519,856)],"x_dlg")
I["x_dlg_f"]=dx([(817,689,1512,718)],"x_dlg_f")
I["x_pdf_ok"]=crop_ext("14_pdf_elegido",[E["lbl"]],"x_pdf_ok")
I["x_modo"]=crop_ext("14_pdf_elegido",[E["modo"]],"x_modo")
I["x_extraer"]=crop_ext("14_pdf_elegido",[E["extraer"]],"x_extraer")
I["x_prev"]=crop_ext("15_pdf_extraido",[E["tabla"]],"x_prev")
I["x_estado_pdf"]=crop_ext("15_pdf_extraido",[E["estado"]],"x_estado_pdf")
I["x_modo_ocr"]=crop_ext("16_modo_ocr",[E["modo"]],"x_modo_ocr")
I["x_foto_prev"]=crop_ext("17_foto_extraida",[E["tabla"]],"x_foto_prev")
I["x_foto_estado"]=crop_ext("17_foto_extraida",[E["estado"]],"x_foto_estado")
I["x_chk"]=crop_ext("17_foto_extraida",[E["chk"]],"x_chk")
I["x_exp"]=crop_ext("17_foto_extraida",[E["exp"]],"x_exp")
I["x_ok18"]=crop_ext("18_exportado_extractor",[E["ok18"]],"x_ok18")
I["x_xls"]=ann(Image.open(S+"21_excel_extraido.png"),[(10,10,884,50)],"x_xls")
I["x_usar"]=crop_ext("17_foto_extraida",[E["sis"],E["fis"]],"x_usar")
I["x_usar_msg"]=crop_ext("19_usar_mensaje",[(325,290,750,470)],"x_usar_msg")
I["x_usado"]=R("20_usado_en_cuadre",[B["lbl_sis"],B["map_sis"]],"x_usado")
print("imágenes:",len(I))
