import faulthandler; faulthandler.dump_traceback_later(150, exit=True)
import os, sys, subprocess, time
sys.path.insert(0, "/opt/cuadre-inventario")
import tkinter as tk
from tkinter import ttk
import cuadre_inventario as ci, extractor_tablas as et
OUT = "/home/claude/shots"; DOC = "/home/claude/test/Documentos"
wm = subprocess.Popen(["openbox"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); time.sleep(2)
root = tk.Tk(); ttk.Style().theme_use("clam"); root.geometry("1180x720+40+20")
app = ci.CuadreInventarioApp(root); root.update()

def shot(name, crop="1240x760+0+0"):
    root.update(); time.sleep(0.4); root.update()
    subprocess.run(["import", "-window", "root", "-crop", crop, "+repage", f"{OUT}/{name}.png"], check=True)
def autocrop(path):
    from PIL import Image, ImageChops
    im = Image.open(path).convert("RGB"); bb = ImageChops.difference(im, Image.new("RGB", im.size, (0, 0, 0))).getbbox()
    if bb: im.crop((max(bb[0]-6,0), max(bb[1]-6,0), min(bb[2]+6,im.width), min(bb[3]+6,im.height))).save(path)
def esperar(vx):
    while vx.hilo.is_alive(): root.update(); time.sleep(0.1)
    for _ in range(15): root.update(); time.sleep(0.1)

def cerrar_msg():
    cand = []
    for padre in (str(vx.win), "."):
        try: cand += root.tk.eval("winfo children %s" % padre).split()
        except Exception: pass
    for w in cand:
        if w.endswith("__tk__messagebox"):
            root.tk.eval("%s.ok invoke" % w); return

shot("11_principal_boton")                      # ventana principal con el botón nuevo
vx = et.VentanaExtractor(app); root.withdraw(); vx.win.geometry("1060x680+80+40"); vx.win.update()
shot("12_extractor_vacio", "1200x760+0+0"); autocrop(f"{OUT}/12_extractor_vacio.png")

def cap_dialog():
    shot("13_dialogo_pdf", "1600x1000+0+0"); autocrop(f"{OUT}/13_dialogo_pdf.png"); subprocess.run(["pkill", "-x", "zenity"])
root.after(3000, cap_dialog); vx.elegir()       # abre el selector real de archivos

app._pedir_archivo = lambda t, n, p: f"{DOC}/Ejemplo_Padron_PDF.pdf"
vx.elegir(); shot("14_pdf_elegido", "1200x760+0+0"); autocrop(f"{OUT}/14_pdf_elegido.png")
vx.extraer(); esperar(vx); shot("15_pdf_extraido", "1200x760+0+0"); autocrop(f"{OUT}/15_pdf_extraido.png")

app._pedir_archivo = lambda t, n, p: f"{DOC}/Ejemplo_Padron_Foto.jpg"
vx.elegir(); vx.cb_modo.current(2); shot("16_modo_ocr", "1200x760+0+0"); autocrop(f"{OUT}/16_modo_ocr.png")
vx.extraer(); esperar(vx); shot("17_foto_extraida", "1200x760+0+0"); autocrop(f"{OUT}/17_foto_extraida.png")

app._pedir_guardado = lambda t, n: f"{DOC}/Ejemplo_Padron_Foto_extraido.xlsx"
def cap_msg():
    shot("18_exportado_extractor", "1200x760+0+0"); autocrop(f"{OUT}/18_exportado_extractor.png"); cerrar_msg()
root.after(1500, cap_msg); vx.exportar()

def cap_msg2():
    shot("19_usar_mensaje", "1200x760+0+0"); autocrop(f"{OUT}/19_usar_mensaje.png"); cerrar_msg()
root.after(1500, cap_msg2); vx.usar("teorico")
root.deiconify(); root.update(); shot("20_usado_en_cuadre")
wm.terminate(); print("OK")
