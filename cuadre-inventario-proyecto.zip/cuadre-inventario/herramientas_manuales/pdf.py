import sys; sys.path.insert(0,"/home/claude/work")
from manuales import *
OUT="/mnt/user-data/outputs/"
import os; os.makedirs(OUT,exist_ok=True)
K=ParagraphStyle("k",fontName="DV",fontSize=10.5,leading=15,textColor=colors.black)
T=ParagraphStyle("t",parent=K,fontName="DVB",fontSize=26,leading=32,alignment=TA_CENTER)
ST=ParagraphStyle("st",parent=K,fontSize=14,leading=20,alignment=TA_CENTER)
H1=ParagraphStyle("h1",parent=K,fontName="DVB",fontSize=15,leading=20,spaceBefore=10,spaceAfter=4)
SUB=ParagraphStyle("sub",parent=K,fontName="DVB",fontSize=11,leading=15,spaceBefore=6,spaceAfter=3)
CAP=ParagraphStyle("cap",parent=K,fontSize=8.5,leading=11,alignment=TA_CENTER)
SM=ParagraphStyle("sm",parent=K,fontSize=9.5,leading=13)

def foot(c,doc):
    c.saveState(); c.setFont("DV",8.5); c.setFillColor(colors.black)
    c.drawString(2*cm,1.2*cm,doc.title); c.drawRightString(A4[0]-2*cm,1.2*cm,"Página %d"%doc.page); c.restoreState()

def img(path,w=15.2*cm):
    from PIL import Image as PI
    iw,ih=PI.open(path).size; h=w*ih/iw
    if h>9.6*cm: w=w*9.6*cm/h; h=9.6*cm
    return RLImage(path,width=w,height=h)

COMPAT="Compatible con Linux Mint 21 y 22 (64 bits)."
def build(fname,title,subtitle,intro,pasos,extra,ref_note=None):
    doc=SimpleDocTemplate(OUT+fname,pagesize=A4,leftMargin=2*cm,rightMargin=2*cm,topMargin=1.8*cm,bottomMargin=2*cm,title=title,author="Augusto")
    s=[Spacer(1,5*cm),Paragraph(title,T),Spacer(1,.6*cm),Paragraph(subtitle,ST),Spacer(1,1.2*cm),
       Paragraph("Versión 1.2 · Noviembre 2026",ST),Paragraph("Preparado para Augusto",ST),Spacer(1,1.5*cm),
       Paragraph("Programa 100 % local: no envía información a internet. "+COMPAT,ST),PageBreak()]
    for p in intro: s.append(p)
    n=0
    for titulo,subs in pasos:
        n+=1; cab=[Spacer(1,.3*cm),Paragraph(f"Paso {n}. {titulo}",H1),HRFlowable(width="100%",thickness=0.8,color=colors.black,spaceAfter=4)]
        for m,(txt,key,cap) in enumerate(subs,1):
            bloque=[Paragraph(f"<b>{n}.{m}</b>&nbsp;&nbsp;{txt}",K),Spacer(1,.15*cm),img(I[key]),Spacer(1,.1*cm),Paragraph(cap,CAP),Spacer(1,.35*cm)]
            s.append(KeepTogether((cab if m==1 else [])+bloque))
    s.append(KeepTogether(list(extra)))
    doc.build(s,onFirstPage=lambda c,d:None,onLaterPages=foot)

def tabla(filas,cw):
    t=Table([[Paragraph(str(c),SM if i else ParagraphStyle("b",parent=SM,fontName="DVB")) for c in f] for i,f in enumerate(filas)],colWidths=cw)
    t.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.6,colors.black),("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),5),("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4)])); return t

REF="Ilustración referencial: el aspecto exacto puede variar según el tema de su Linux Mint."
REAL="Captura real del programa."
# ===================================================== MANUAL DE INSTALACIÓN
intro_i=[Paragraph("Antes de empezar",H1),HRFlowable(width="100%",thickness=0.8,color=colors.black,spaceAfter=4),
 Paragraph("Este manual explica cómo instalar <b>Cuadre de Inventario / Kardex</b> en Linux Mint usando solo el ratón. No necesita escribir comandos ni abrir la terminal.",K),Spacer(1,.2*cm),
 Paragraph("<b>Qué necesita:</b>",K),
 Paragraph("1. El archivo instalador <b>cuadre-inventario_1.2.deb</b>.<br/>2. Un usuario con permisos de administrador (la contraseña con la que inicia sesión).<br/>3. Conexión a internet <b>solo durante la instalación</b>, para descargar los componentes que faltan (Python, Excel, selector de archivos y el lector de texto en imágenes Tesseract, en español).<br/>4. Un equipo de 64 bits (el instalador es para amd64, lo habitual en Linux Mint). Después el programa funciona sin internet.",K),Spacer(1,.2*cm),
 Paragraph("<b>Nota sobre las imágenes:</b> las pantallas del administrador de archivos, del instalador de paquetes, de la contraseña y del menú son ilustraciones referenciales; el aspecto exacto depende de su tema de Linux Mint. Las capturas de la ventana del programa son reales.",SM)]
pi=[("Ubicar el instalador",[
  ("Abra el <b>Administrador de archivos</b> y entre a la carpeta donde guardó el instalador (por ejemplo, <b>Descargas</b>).","files_plain",REF),
  ("Localice el archivo <b>cuadre-inventario_1.2.deb</b>. Tiene un ícono de caja marrón.","files",REF)]),
 ("Abrir el instalador de paquetes",[
  ("Haga <b>doble clic</b> sobre <b>cuadre-inventario_1.2.deb</b>.","files",REF),
  ("Se abre la ventana <b>Instalador de paquetes</b>. Lea la descripción: debe decir «Cuadre de Inventario / Kardex».","gd_listo",REF)]),
 ("Instalar el programa",[
  ("Pulse el botón verde <b>Instalar paquete</b>.","gd_btn",REF),
  ("Aparece una ventana de autenticación. Escriba la <b>contraseña</b> de su usuario.","au_pass",REF),
  ("Pulse <b>Autenticar</b>.","au_btn",REF),
  ("Espere mientras se instala. La barra de progreso avanza sola; puede tardar unos minutos la primera vez porque descarga componentes.","gd_prog",REF),
  ("Cuando termine, el estado dirá <b>Instalación finalizada correctamente</b>.","gd_fin",REF),
  ("Pulse <b>Cerrar</b>. Ya puede borrar el archivo .deb si lo desea.","gd_close",REF)]),
 ("Comprobar que quedó instalado",[
  ("Haga clic en el <b>botón del menú</b> de Linux Mint (esquina inferior izquierda).","desk",REF),
  ("En el menú, haga clic en la caja de búsqueda.","menu_open",REF),
  ("Escriba <b>Cuadre</b>.","menu_type",REF),
  ("Haga clic en <b>Cuadre de Inventario</b>.","menu_res",REF),
  ("Se abre la ventana del programa. La instalación terminó correctamente.","app0",REAL)]),
 ("Desinstalar (opcional)",[
  ("Abra el menú, busque <b>Cuadre</b> y haga <b>clic derecho</b> sobre la entrada.","ctx",REF),
  ("Elija <b>Desinstalar</b>.","ctx_u",REF),
  ("Escriba su contraseña si se la solicita y confirme.","au_pass",REF)])]
ex_i=[Spacer(1,.4*cm),Paragraph("Si algo no funciona",H1),HRFlowable(width="100%",thickness=0.8,color=colors.black,spaceAfter=6),
 tabla([["Problema","Qué hacer"],
  ["Al hacer doble clic se abre otro programa (por ejemplo, un archivador)","Haga clic derecho sobre el .deb, elija <b>Abrir con</b> y seleccione <b>Instalador de paquetes</b>. También puede usar el <b>Gestor de software</b> si su equipo lo ofrece."],
  ["El instalador dice que faltan dependencias o no puede descargarlas","Verifique que el equipo tenga internet y vuelva a pulsar <b>Instalar paquete</b>. En Linux Mint conviene tener actualizado el sistema (<b>Gestor de actualizaciones</b>)."],
  ["Contraseña rechazada","Use la contraseña con la que inicia sesión. Si su usuario no es administrador, pida ayuda a quien administra el equipo."],
  ["El programa no abre o aparece «Error inesperado»","Abra su <b>Carpeta personal</b> y busque el archivo <b>cuadre_inventario_errores.log</b>. Envíelo para poder corregir el problema (no necesita abrirlo)."],
  ["No aparece «Cuadre de Inventario» en el menú","Cierre y vuelva a abrir el menú, o cierre sesión y vuelva a entrar."]],[6.2*cm,10.8*cm])]
build("Manual_Instalacion_Linux_Cuadre_Inventario.pdf","Manual de Instalación (Linux Mint)","Cuadre de Inventario / Kardex en Linux Mint",intro_i,pi,ex_i)

# ===================================================== MANUAL DE USUARIO
intro_u=[Paragraph("¿Para qué sirve?",H1),HRFlowable(width="100%",thickness=0.8,color=colors.black,spaceAfter=4),
 Paragraph("<b>Cuadre de Inventario / Kardex</b> compara el Excel del <b>Sistema</b> (lo que debería haber) con el Excel del <b>Conteo Físico</b> (lo que se contó) y muestra qué ítems están conformes, cuáles faltan y cuáles sobran. Al final genera un acta en Excel lista para presentar.",K),Spacer(1,.25*cm),
 Paragraph("<b>Qué necesita antes de empezar</b>",K),
 Paragraph("• Un Excel del <b>Sistema</b> con, al menos: código, descripción y cantidad (el precio unitario es opcional y sirve para valorizar la diferencia).<br/>• Un Excel del <b>Conteo Físico</b> con código, descripción y cantidad.<br/>• Los archivos pueden tener títulos o logos arriba: el programa busca solo dónde empieza la tabla.<br/>• Si un ítem se contó en varias filas (por ejemplo, en distintos pasillos), el programa las suma automáticamente.",K),Spacer(1,.25*cm),
 Paragraph("<b>Cómo leer los colores</b>",K),Spacer(1,.1*cm),
 tabla([["Estado","Significa"],["CONFORME (verde)","El conteo físico coincide con el sistema."],["FALTANTE (rojo)","Se contó menos de lo que dice el sistema."],["SOBRANTE (amarillo)","Se contó más de lo que dice el sistema, o el ítem no existe en el sistema."]],[5*cm,12*cm]),Spacer(1,.25*cm),
 Paragraph("<b>Novedad (desde la versión 1.1):</b> el programa también convierte en Excel las tablas que vienen en un <b>PDF</b> o en una <b>foto</b> (Paso 8), y puede cargarlas directamente como Sistema o Conteo Físico.  Junto a este manual se entregan archivos de práctica: <b>Ejemplo_Sistema.xlsx</b> y <b>Ejemplo_Conteo_Fisico.xlsx</b> (Pasos 1 a 7), y <b>Ejemplo_Padron_PDF.pdf</b> y <b>Ejemplo_Padron_Foto.jpg</b> (Paso 8). Los recuadros rojos y los números indican dónde hacer clic o qué mirar.",SM)]
pu=[("Abrir el programa",[
  ("Haga clic en el <b>botón del menú</b> de Linux Mint.","desk",REF),
  ("Haga clic en la caja de búsqueda del menú.","menu_open",REF),
  ("Escriba <b>Cuadre</b>.","menu_type",REF),
  ("Haga clic en <b>Cuadre de Inventario</b>.","menu_res",REF),
  ("Se abre la ventana principal, con tres zonas: carga de archivos, asignación de columnas y la tabla de resultados.","app0",REAL)]),
 ("Cargar el Excel del Sistema",[
  ("Pulse el botón <b>Cargar Excel Sistema (Teórico)</b>.","u_btn_sis",REAL),
  ("Se abre el selector de archivos. Ubique la carpeta donde está el Excel; por defecto se abre en <b>Documentos</b>.","u_dlg_sis",REAL),
  ("Haga clic sobre el archivo del Sistema (en el ejemplo, <b>Ejemplo_Sistema.xlsx</b>).","u_dlg_sis_f",REAL),
  ("Pulse <b>OK</b> (o <b>Aceptar</b>). El botón se activa al elegir el archivo.","u_dlg_ok",REAL),
  ("Compruebe que aparece el nombre del archivo y su número de filas.","u_lbl_sis",REAL),
  ("Revise la fila <b>SISTEMA (TEÓRICO)</b>: el programa elige solo las columnas Código, Descripción, Cantidad y Precio. Si alguna no es la correcta, despliegue la lista y elija la columna adecuada.","u_map_sis",REAL)]),
 ("Cargar el Excel del Conteo Físico",[
  ("Pulse el botón <b>Cargar Excel Conteo Físico</b>.","u_btn_fis",REAL),
  ("Se abre otra vez el selector de archivos. Ubique la carpeta del conteo.","u_dlg_fis",REAL),
  ("Haga clic sobre el archivo del conteo (en el ejemplo, <b>Ejemplo_Conteo_Fisico.xlsx</b>).","u_dlg_fis_f",REAL),
  ("Pulse <b>OK</b> (o <b>Aceptar</b>).","u_dlg_fis_ok",REAL),
  ("Compruebe el nombre del archivo y su número de filas.","u_lbl_fis",REAL),
  ("Revise la fila <b>CONTEO FÍSICO</b>: Código, Descripción y Cantidad. Corrija con la lista desplegable si hiciera falta.","u_map_fis",REAL),
  ("Deje marcada la casilla <b>Cruzar por nombre similar</b> si algunos ítems del conteo no tienen código: el programa los empareja por parecido del nombre (más de 86 %). Desmárquela si prefiere cruzar solo por código.","u_chk",REAL)]),
 ("Procesar y cruzar el inventario",[
  ("Verifique por última vez las columnas elegidas en ambos archivos.","u_maps",REAL),
  ("Pulse <b>Procesar y Cruzar Inventario</b>.","u_proc",REAL),
  ("Lea el resumen de la derecha: total de ítems, conformes, faltantes y sobrantes.","u_res",REAL),
  ("Revise la tabla. Primero salen los faltantes (1), luego los sobrantes (2) y al final los conformes (3).","u_rows",REAL)]),
 ("Filtrar la vista",[
  ("Si solo quiere ver un tipo de ítems, use la lista <b>Filtrar vista</b>.","u_filtro",REAL),
  ("Elija, por ejemplo, <b>FALTANTE</b>.","u_filtro2",REAL),
  ("La tabla muestra solo los faltantes (el resumen sigue contando el total).","u_falt",REAL),
  ("Para volver a ver todo, elija <b>TODOS</b> en la misma lista.","u_filtro3",REAL)]),
 ("Exportar el acta a Excel",[
  ("Pulse <b>Exportar Excel con Colores</b>.","u_exp",REAL),
  ("Se abre el selector para guardar. Escriba o confirme el nombre del archivo; el programa propone <b>Cuadre_Inventario_Kardex.xlsx</b>. Elija la carpeta, por ejemplo <b>Documentos</b>.","u_sv_dlg",REAL),
  ("Pulse <b>OK</b> (o <b>Guardar</b>).","u_sv_ok",REAL),
  ("Aparece el aviso «Reporte guardado correctamente». Pulse <b>OK</b>.","u_ok",REAL),
  ("Abra el archivo con LibreOffice Calc o Excel. El título y los encabezados están en azul, y cada fila lleva el color de su estado.","u_xls",REAL),
  ("Al final está la fila <b>TOTALES GENERALES</b>. Las columnas Diferencia y Valor son fórmulas vivas: puede ajustar un número a mano y se recalculan. El archivo está listo para imprimir en horizontal.","u_xls2",REAL)]),
 ("Empezar un nuevo cuadre",[
  ("Pulse <b>Limpiar Todo</b>.","u_lim",REAL),
  ("La pantalla queda vacía y la barra inferior indica que está lista para un nuevo cuadre. Repita desde el Paso 2.","u_lim2",REAL)]),
 ("Extraer tablas de un PDF o de una foto a Excel (nuevo)",[
  ("Estando en la ventana principal, pulse <b>Extraer tablas de PDF o foto → Excel…</b>.","x_btn",REAL),
  ("Se abre la ventana del extractor, con tres zonas: elegir el documento, opciones y vista previa de los datos.","x_vacia",REAL),
  ("Pulse <b>Elegir PDF o foto…</b>.","x_elegir",REAL),
  ("En el selector de archivos, ubique la carpeta donde está el documento.","x_dlg",REAL),
  ("Haga clic sobre el documento. Para PDF digitales (los que generan los sistemas) use, por ejemplo, <b>Ejemplo_Padron_PDF.pdf</b>, y pulse <b>OK</b>.","x_dlg_f",REAL),
  ("Compruebe que el nombre del archivo aparece junto al botón.","x_pdf_ok",REAL),
  ("En <b>Tipo de documento</b> deje <b>Automático (recomendado)</b>: el programa decide si lee el texto del PDF o si necesita OCR.","x_modo",REAL),
  ("Pulse <b>▶ Extraer tablas</b>.","x_extraer",REAL),
  ("Revise la vista previa: cada tabla del PDF se une en una sola, sin repetir los encabezados de cada página, y se agrega la columna <b>Pagina_Origen</b>.","x_prev",REAL),
  ("Lea el mensaje de la barra inferior: indica cuántas filas y columnas se extrajeron.","x_estado_pdf",REAL),
  ("<b>Si el documento es una foto o un PDF escaneado:</b> elíjalo del mismo modo (por ejemplo, <b>Ejemplo_Padron_Foto.jpg</b>) y en <b>Tipo de documento</b> elija <b>Escaneado o foto (OCR)</b>.","x_modo_ocr",REAL),
  ("Pulse <b>▶ Extraer tablas</b> y espere: el OCR puede tardar unos segundos (más si la foto está girada). La vista previa muestra los datos leídos.","x_foto_prev",REAL),
  ("Como el texto de una foto lo lee un programa, <b>revise siempre los datos</b>: la barra inferior lo recuerda. Para mejores resultados, tome la foto de frente, con buena luz y sin sombras.","x_foto_estado",REAL),
  ("Deje marcada <b>Convertir números y fechas</b> para que los montos y las fechas queden como números y fechas reales en Excel (los códigos con ceros iniciales se respetan). Desmárquela si prefiere todo como texto.","x_chk",REAL),
  ("Para guardar la tabla, pulse <b>Exportar a Excel</b>, elija carpeta y nombre en el selector y pulse <b>OK</b>.","x_exp",REAL),
  ("Aparece el aviso «Tabla guardada correctamente». Pulse <b>OK</b>.","x_ok18",REAL),
  ("Abra el archivo en LibreOffice Calc o Excel: encabezados en negrita, bordes, columnas ajustadas y listo para imprimir en horizontal.","x_xls",REAL),
  ("<b>Opcional:</b> para usar los datos extraídos directamente en un cuadre, pulse <b>Usar como Sistema (Teórico)</b> o <b>Usar como Conteo Físico</b> (1 y 2).","x_usar",REAL),
  ("Aparece un aviso de confirmación. Pulse <b>OK</b>.","x_usar_msg",REAL),
  ("De vuelta en la ventana principal, los datos ya están cargados y las columnas asignadas. Verifíquelas y siga desde el <b>Paso 4</b>.","x_usado",REAL)])]
ex_u=[Spacer(1,.4*cm),Paragraph("Problemas frecuentes",H1),HRFlowable(width="100%",thickness=0.8,color=colors.black,spaceAfter=6),
 tabla([["Situación","Qué hacer"],
  ["Aparece un ítem como SOBRANTE y también como FALTANTE","El código o el nombre se escribió distinto en cada Excel. Corrija el dato en el Excel y vuelva a procesar, o marque la casilla de nombre similar."],
  ["Las columnas elegidas no son las correctas","Despliegue la lista de cada columna y elija la correcta; luego pulse <b>Procesar y Cruzar Inventario</b> otra vez."],
  ["Aparece «Error inesperado»","El programa guarda el detalle en el archivo <b>cuadre_inventario_errores.log</b> de su Carpeta personal. Envíelo para poder corregir el problema."],
  ["Un ítem sin código aparece como «SIN CÓDIGO»","Es normal: ese ítem no traía código. Se cruza por nombre."],
  ["Mensaje «No se pudo abrir el archivo»","Cierre el Excel si lo tiene abierto en otro programa y verifique que sea .xlsx, .xlsm o .xls."],
  ["«No se detectaron tablas» en un PDF","Probablemente es un escaneo: cambie el tipo de documento a <b>Escaneado o foto (OCR)</b> y extraiga de nuevo."],
  ["El OCR leyó mal algunos datos","Mejore la foto (de frente, con luz pareja, sin sombras ni dobleces) o corrija el dato en el Excel exportado. Siempre revise los datos leídos con OCR."],
  ["Los precios salen en 0.00","Elija la columna de precio en «Precio (opc.)». Los ítems que solo existen en el conteo físico no tienen precio en el sistema."]],[6.2*cm,10.8*cm])]
build("Manual_Usuario_Linux_Cuadre_Inventario.pdf","Manual de Usuario (Linux Mint)","Cuadre de Inventario / Kardex en Linux Mint",intro_u,pu,ex_u)
print("PDFs ok")
